"use client"

import type React from "react"

import { memo, useState, useCallback, useMemo } from "react"
import { PageContainer } from "./page-container"
import { EnhancedCard } from "./enhanced-card"
import { EnhancedButton } from "./enhanced-button"
import { InfoModal } from "./info-modal"
import { SuccessBurst } from "./success-burst"
import { ParticleSystem } from "./particle-system"
import { Code, FileText, Eye, CheckCircle, AlertCircle } from "lucide-react"

export const Page2_HtmlBasics = memo(() => {
  const [showModal, setShowModal] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [showParticles, setShowParticles] = useState(false)
  const [userCode, setUserCode] = useState("")
  const [codeResult, setCodeResult] = useState("")
  const [completedExercises, setCompletedExercises] = useState<Set<string>>(new Set())

  const htmlElements = useMemo(
    () => [
      {
        id: "heading",
        tag: "<h1>",
        description: "Main heading - largest and most important",
        example: "<h1>Welcome to My Website</h1>",
      },
      {
        id: "paragraph",
        tag: "<p>",
        description: "Paragraph of text content",
        example: "<p>This is a paragraph of text.</p>",
      },
      {
        id: "link",
        tag: "<a>",
        description: "Hyperlink to other pages or resources",
        example: '<a href="https://example.com">Visit Example</a>',
      },
      {
        id: "image",
        tag: "<img>",
        description: "Display images on your webpage",
        example: '<img src="image.jpg" alt="Description">',
      },
      {
        id: "div",
        tag: "<div>",
        description: "Generic container for grouping elements",
        example: "<div>Content goes here</div>",
      },
    ],
    [],
  )

  const basicStructure = useMemo(
    () => `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First Webpage</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <p>This is my first HTML page.</p>
</body>
</html>`,
    [],
  )

  const handleOpenModal = useCallback(() => {
    setShowModal(true)
  }, [])

  const handleCloseModal = useCallback(() => {
    setShowModal(false)
  }, [])

  const handleCodeChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setUserCode(e.target.value)
  }, [])

  const handleRunCode = useCallback(() => {
    if (userCode.includes("<h1>") && userCode.includes("<p>")) {
      setCodeResult("Great! Your HTML structure looks correct.")
      setShowSuccess(true)
      setShowParticles(true)
      setTimeout(() => setShowParticles(false), 3000)
    } else {
      setCodeResult("Try adding both an <h1> heading and a <p> paragraph to your HTML.")
    }
  }, [userCode])

  const handleExerciseComplete = useCallback((exerciseId: string) => {
    setCompletedExercises((prev) => new Set([...prev, exerciseId]))
    setShowSuccess(true)
  }, [])

  const isCompleted = useCallback(
    (exerciseId: string) => {
      return completedExercises.has(exerciseId)
    },
    [completedExercises],
  )

  return (
    <PageContainer
      title="HTML Basics: Building Blocks of the Web"
      subtitle="Learn the fundamental elements that make up every webpage"
    >
      <ParticleSystem active={showParticles} />

      <div className="space-y-8">
        {/* What is HTML */}
        <EnhancedCard className="animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-roots-primary-accent rounded-xl">
              <FileText className="w-8 h-8 text-roots-text" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-roots-text mb-3 font-inter">What is HTML?</h2>
              <p className="text-roots-dark-gray mb-4 font-inter leading-relaxed">
                HTML (HyperText Markup Language) is the standard markup language for creating web pages. It describes
                the structure and content of a webpage using elements and tags.
              </p>
              <div className="card-container p-4">
                <p className="text-roots-text font-inter text-sm">
                  <strong>Think of HTML as the skeleton of a webpage</strong> - it provides the basic structure that
                  holds everything together, just like bones support your body.
                </p>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* HTML Elements */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">Essential HTML Elements</h3>
          <div className="grid gap-4">
            {htmlElements.map((element, index) => (
              <div
                key={element.id}
                className="border border-roots-border-line rounded-lg p-4 hover:bg-roots-light-gray transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded font-mono text-sm">
                    {element.tag}
                  </code>
                  <EnhancedButton
                    size="sm"
                    variant={isCompleted(element.id) ? "success" : "secondary"}
                    onClick={() => handleExerciseComplete(element.id)}
                  >
                    {isCompleted(element.id) ? "✓ Learned" : "Mark as Learned"}
                  </EnhancedButton>
                </div>
                <p className="text-roots-dark-gray mb-2 font-inter text-sm">{element.description}</p>
                <code className="block bg-roots-container-bg p-2 rounded text-sm font-mono text-roots-text">
                  {element.example}
                </code>
              </div>
            ))}
          </div>
        </EnhancedCard>

        {/* Basic HTML Structure */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
          <div className="flex items-center gap-3 mb-6">
            <Code className="w-6 h-6 text-roots-icon-color" />
            <h3 className="text-xl font-bold text-roots-text font-inter">Basic HTML Document Structure</h3>
          </div>
          <div className="bg-roots-container-bg p-4 rounded-lg mb-4">
            <pre className="text-sm font-mono text-roots-text overflow-x-auto">{basicStructure}</pre>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-bold text-roots-text mb-2 font-inter">Document Structure:</h4>
              <ul className="space-y-1 text-roots-dark-gray font-inter">
                <li>
                  • <code>&lt;!DOCTYPE html&gt;</code> - Document type declaration
                </li>
                <li>
                  • <code>&lt;html&gt;</code> - Root element
                </li>
                <li>
                  • <code>&lt;head&gt;</code> - Metadata section
                </li>
                <li>
                  • <code>&lt;body&gt;</code> - Visible content
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-roots-text mb-2 font-inter">Key Points:</h4>
              <ul className="space-y-1 text-roots-dark-gray font-inter">
                <li>• Tags come in pairs (opening and closing)</li>
                <li>• Proper nesting is essential</li>
                <li>• Indentation improves readability</li>
                <li>• Always include alt text for images</li>
              </ul>
            </div>
          </div>
        </EnhancedCard>

        {/* Interactive Exercise */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
          <div className="flex items-center gap-3 mb-6">
            <Eye className="w-6 h-6 text-roots-icon-color" />
            <h3 className="text-xl font-bold text-roots-text font-inter">Try It Yourself!</h3>
          </div>
          <p className="text-roots-dark-gray mb-4 font-inter">
            Create a simple HTML page with a heading and a paragraph. Type your HTML code below:
          </p>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-roots-text mb-2 font-inter">Your HTML Code:</label>
              <textarea
                value={userCode}
                onChange={handleCodeChange}
                placeholder="Type your HTML here..."
                className="w-full h-32 p-3 border-2 border-roots-medium-gray rounded-lg bg-roots-page-bg text-roots-text font-mono text-sm resize-none focus:border-roots-icon-color focus:outline-none"
              />
            </div>
            <div className="flex gap-3">
              <EnhancedButton onClick={handleRunCode}>
                <Eye className="w-4 h-4 mr-2" />
                Check My Code
              </EnhancedButton>
              <EnhancedButton variant="secondary" onClick={() => setUserCode(basicStructure)}>
                Use Example
              </EnhancedButton>
            </div>
            {codeResult && (
              <div
                className={`p-3 rounded-lg flex items-start gap-2 ${
                  codeResult.includes("Great")
                    ? "bg-green-50 border border-green-200"
                    : "bg-orange-50 border border-orange-200"
                }`}
              >
                {codeResult.includes("Great") ? (
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                )}
                <p className="text-sm font-inter">{codeResult}</p>
              </div>
            )}
          </div>
        </EnhancedCard>

        {/* Quick Tips */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-4 font-inter">Quick Tips for Writing HTML</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-roots-text font-inter">Use Semantic Elements</h4>
                  <p className="text-sm text-roots-dark-gray font-inter">
                    Choose elements based on meaning, not appearance
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-roots-text font-inter">Validate Your Code</h4>
                  <p className="text-sm text-roots-dark-gray font-inter">Use online validators to check for errors</p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-roots-text font-inter">Keep It Clean</h4>
                  <p className="text-sm text-roots-dark-gray font-inter">Use proper indentation and formatting</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-roots-text font-inter">Add Comments</h4>
                  <p className="text-sm text-roots-dark-gray font-inter">Document your code for future reference</p>
                </div>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <EnhancedButton size="lg" onClick={handleOpenModal}>
            View HTML Reference
          </EnhancedButton>
          <EnhancedButton size="lg" variant="success">
            Continue to Next Lesson
          </EnhancedButton>
        </div>
      </div>

      {/* HTML Reference Modal */}
      <InfoModal isOpen={showModal} onClose={handleCloseModal} title="HTML Quick Reference">
        <div className="space-y-4">
          <div>
            <h4 className="font-bold text-roots-text mb-2 font-inter">Common HTML Tags</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
              <div>
                <code>&lt;h1&gt; to &lt;h6&gt;</code> - Headings
              </div>
              <div>
                <code>&lt;p&gt;</code> - Paragraph
              </div>
              <div>
                <code>&lt;a&gt;</code> - Links
              </div>
              <div>
                <code>&lt;img&gt;</code> - Images
              </div>
              <div>
                <code>&lt;div&gt;</code> - Division/Container
              </div>
              <div>
                <code>&lt;span&gt;</code> - Inline container
              </div>
              <div>
                <code>&lt;ul&gt;, &lt;ol&gt;, &lt;li&gt;</code> - Lists
              </div>
              <div>
                <code>&lt;table&gt;, &lt;tr&gt;, &lt;td&gt;</code> - Tables
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-roots-text mb-2 font-inter">HTML Attributes</h4>
            <div className="space-y-1 text-sm text-roots-dark-gray font-inter">
              <div>
                <code>href</code> - Link destination
              </div>
              <div>
                <code>src</code> - Image source
              </div>
              <div>
                <code>alt</code> - Alternative text
              </div>
              <div>
                <code>class</code> - CSS class name
              </div>
              <div>
                <code>id</code> - Unique identifier
              </div>
            </div>
          </div>
        </div>
      </InfoModal>

      <SuccessBurst
        show={showSuccess}
        message="Excellent work! You're mastering HTML!"
        onComplete={() => setShowSuccess(false)}
      />
    </PageContainer>
  )
})

Page2_HtmlBasics.displayName = "Page2_HtmlBasics"
