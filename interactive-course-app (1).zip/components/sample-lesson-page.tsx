"use client"

import { memo } from "react"
import { LessonPageLayout } from "./lesson-page-layout"
import {
  LessonContent,
  LessonSection,
  LessonParagraph,
  LessonImage,
  LessonList,
  LessonHighlight,
  LessonQuote,
} from "./lesson-content"

interface SampleLessonPageProps {
  currentLesson?: number
  onPreviousLesson?: () => void
  onNextLesson?: () => void
}

export const SampleLessonPage = memo<SampleLessonPageProps>(({ currentLesson = 3, onPreviousLesson, onNextLesson }) => {
  return (
    <LessonPageLayout
      moduleTitle="Understanding Assumable Mortgages"
      lessonTitle="Market Trends and Benefits"
      currentLesson={currentLesson}
      totalLessons={15}
      completedLessons={currentLesson - 1}
      previousLessonTitle="Introduction to Assumable Mortgages"
      nextLessonTitle="Mortgage Calculator Tools"
      canGoBack={currentLesson > 1}
      canGoForward={currentLesson < 15}
      onPreviousLesson={onPreviousLesson}
      onNextLesson={onNextLesson}
    >
      <LessonContent>
        <LessonSection title="Current Market Overview">
          <LessonParagraph>
            The assumable mortgage market has experienced significant growth in recent years, driven by rising interest
            rates and increased awareness among both buyers and sellers. Understanding these trends is crucial for real
            estate professionals looking to leverage this powerful tool.
          </LessonParagraph>

          <LessonHighlight variant="info">
            <strong>Key Insight:</strong> When interest rates rise above 6%, assumable mortgages become increasingly
            attractive to buyers who can secure rates 2-3% lower than current market rates.
          </LessonHighlight>

          <LessonImage
            src="/placeholder.svg?height=400&width=800&text=Market+Trends+Chart"
            alt="Chart showing assumable mortgage market trends over the past 5 years"
            caption="Assumable mortgage transaction volume has increased 340% since 2020"
          />
        </LessonSection>

        <LessonSection title="Primary Benefits for Buyers">
          <LessonParagraph>
            Assumable mortgages offer several compelling advantages that can make the difference in competitive markets:
          </LessonParagraph>

          <LessonList
            items={[
              "Lower interest rates compared to current market conditions",
              "Reduced closing costs (typically $2,000-$5,000 vs $8,000-$15,000)",
              "Faster closing process (30-45 days vs 45-60 days)",
              "No mortgage insurance required in many cases",
              "Competitive advantage in multiple offer situations",
            ]}
          />

          <LessonQuote author="Sarah Johnson, Top Real Estate Agent">
            I've helped over 50 buyers secure assumable mortgages in the past year alone. The savings are real – my
            clients have saved an average of $180,000 over the life of their loans compared to getting new financing.
          </LessonQuote>
        </LessonSection>

        <LessonSection title="Seller Advantages">
          <LessonParagraph>
            While buyers often drive assumable mortgage transactions, sellers also benefit significantly:
          </LessonParagraph>

          <LessonList
            ordered
            items={[
              "Faster sales in challenging markets",
              "Higher sale prices due to financing incentive",
              "Reduced carrying costs with quicker closings",
              "Competitive differentiation from other listings",
              "Potential for multiple offers and bidding wars",
            ]}
          />

          <LessonHighlight variant="success">
            <strong>Success Story:</strong> A recent listing with an assumable 3.2% mortgage received 12 offers within
            48 hours, selling for 8% above asking price.
          </LessonHighlight>
        </LessonSection>

        <LessonSection title="Market Data and Statistics">
          <LessonParagraph>
            Recent market analysis reveals compelling trends in assumable mortgage adoption:
          </LessonParagraph>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 my-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">340%</div>
                <div className="text-sm text-gray-600">Growth since 2020</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">$180K</div>
                <div className="text-sm text-gray-600">Average savings</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">15 days</div>
                <div className="text-sm text-gray-600">Faster closings</div>
              </div>
            </div>
          </div>

          <LessonHighlight variant="warning">
            <strong>Important Note:</strong> While assumable mortgages offer significant benefits, they require careful
            qualification and documentation. Always work with experienced lenders familiar with the assumption process.
          </LessonHighlight>
        </LessonSection>
      </LessonContent>
    </LessonPageLayout>
  )
})

SampleLessonPage.displayName = "SampleLessonPage"
