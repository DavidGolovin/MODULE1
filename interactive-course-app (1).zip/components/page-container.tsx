"use client"

import { memo, type ReactNode } from "react"

interface PageContainerProps {
  children: ReactNode
  title?: string
  subtitle?: string
  className?: string
}

export const PageContainer = memo<PageContainerProps>(({ children, title, subtitle, className = "" }) => {
  return (
    <div className={`min-h-screen bg-roots-page-bg font-inter ${className}`}>
      {(title || subtitle) && (
        <header className="bg-gradient-to-r from-roots-container-bg to-roots-light-gray border-b border-roots-border-line">
          <div className="container mx-auto px-4 py-8 max-w-6xl">
            {title && (
              <h1 className="text-3xl md:text-4xl font-bold text-roots-text mb-2 animate-fade-in-up">{title}</h1>
            )}
            {subtitle && (
              <p className="text-lg text-roots-dark-gray animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                {subtitle}
              </p>
            )}
          </div>
        </header>
      )}
      <main className="container mx-auto px-4 py-8 max-w-6xl">{children}</main>
    </div>
  )
})

PageContainer.displayName = "PageContainer"
