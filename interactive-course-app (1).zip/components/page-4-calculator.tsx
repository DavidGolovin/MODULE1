"use client"

import { memo, useState, useCallback } from "react"

interface Page4_CalculatorProps {
  onNextPage?: () => void
  onPrevPage?: () => void
  onPageCompletion?: (completed: boolean) => void
  isCompleted?: boolean
}

export const Page4_Calculator = memo<Page4_CalculatorProps>(
  ({ onNextPage, onPrevPage, onPageCompletion, isCompleted = false }) => {
    const [num1, setNum1] = useState<number | null>(null)
    const [num2, setNum2] = useState<number | null>(null)
    const [operation, setOperation] = useState<string | null>(null)
    const [result, setResult] = useState<number | null>(null)
    const [hasCalculated, setHasCalculated] = useState(false)

    const handleNumberClick = useCallback(
      (number: number) => {
        if (operation === null) {
          setNum1(num1 === null ? number : Number(String(num1) + number))
        } else {
          setNum2(num2 === null ? number : Number(String(num2) + number))
        }
      },
      [num1, num2, operation],
    )

    const handleOperationClick = useCallback(
      (op: string) => {
        if (num1 !== null) {
          setOperation(op)
        }
      },
      [num1],
    )

    const handleCalculate = useCallback(() => {
      if (num1 !== null && num2 !== null && operation !== null) {
        let calculatedResult: number
        switch (operation) {
          case "+":
            calculatedResult = num1 + num2
            break
          case "-":
            calculatedResult = num1 - num2
            break
          case "*":
            calculatedResult = num1 * num2
            break
          case "/":
            if (num2 === 0) {
              alert("Cannot divide by zero!")
              return
            }
            calculatedResult = num1 / num2
            break
          default:
            calculatedResult = 0
        }
        setResult(calculatedResult)
        setHasCalculated(true)

        // Mark lesson as completed when first calculation is done
        if (onPageCompletion && !hasCalculated) {
          onPageCompletion(true)
        }
      }
    }, [num1, num2, operation, hasCalculated, onPageCompletion])

    const handleClear = useCallback(() => {
      setNum1(null)
      setNum2(null)
      setOperation(null)
      setResult(null)
    }, [])

    return (
      <div className="container mx-auto px-4 py-8 font-inter">
        <div className="global-container max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary font-inter mb-4">Interactive Calculator</h1>
            <p className="text-gray-600 font-inter">
              Practice building interactive functionality with this calculator exercise
            </p>
          </div>

          <div className="space-y-6">
            {/* Display Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="num1" className="block text-primary text-sm font-bold mb-2 font-inter">
                  Number 1:
                </label>
                <input
                  type="text"
                  id="num1"
                  className="input-field w-full"
                  value={num1 !== null ? num1 : ""}
                  readOnly
                  aria-label="First number"
                />
              </div>

              <div>
                <label htmlFor="operation" className="block text-primary text-sm font-bold mb-2 font-inter">
                  Operation:
                </label>
                <input
                  type="text"
                  id="operation"
                  className="input-field w-full"
                  value={operation !== null ? operation : ""}
                  readOnly
                  aria-label="Mathematical operation"
                />
              </div>

              <div>
                <label htmlFor="num2" className="block text-primary text-sm font-bold mb-2 font-inter">
                  Number 2:
                </label>
                <input
                  type="text"
                  id="num2"
                  className="input-field w-full"
                  value={num2 !== null ? num2 : ""}
                  readOnly
                  aria-label="Second number"
                />
              </div>

              <div>
                <label htmlFor="result" className="block text-primary text-sm font-bold mb-2 font-inter">
                  Result:
                </label>
                <input
                  type="text"
                  id="result"
                  className="input-field w-full font-bold"
                  value={result !== null ? result : ""}
                  readOnly
                  aria-label="Calculation result"
                />
              </div>
            </div>

            {/* Number Pad */}
            <div>
              <h3 className="text-lg font-bold text-primary mb-4 font-inter">Numbers</h3>
              <div className="grid grid-cols-4 gap-2">
                {[7, 8, 9, 4, 5, 6, 1, 2, 3, 0].map((number) => (
                  <button
                    key={number}
                    className="btn-primary py-3 px-4 text-lg font-bold"
                    onClick={() => handleNumberClick(number)}
                    aria-label={`Number ${number}`}
                  >
                    {number}
                  </button>
                ))}
                <button
                  className="btn-secondary py-3 px-4 text-lg font-bold col-span-2"
                  onClick={handleClear}
                  aria-label="Clear all"
                >
                  Clear
                </button>
              </div>
            </div>

            {/* Operations */}
            <div>
              <h3 className="text-lg font-bold text-primary mb-4 font-inter">Operations</h3>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { op: "+", label: "Add" },
                  { op: "-", label: "Subtract" },
                  { op: "*", label: "Multiply" },
                  { op: "/", label: "Divide" },
                ].map(({ op, label }) => (
                  <button
                    key={op}
                    className="btn-primary py-3 px-4 text-lg font-bold"
                    onClick={() => handleOperationClick(op)}
                    aria-label={label}
                  >
                    {op}
                  </button>
                ))}
              </div>
            </div>

            {/* Calculate Button */}
            <div className="text-center">
              <button
                className="btn-primary py-4 px-8 text-xl font-bold"
                onClick={handleCalculate}
                disabled={num1 === null || num2 === null || operation === null}
                aria-label="Calculate result"
              >
                Calculate =
              </button>
            </div>

            {/* Success Message */}
            {hasCalculated && (
              <div className="text-center p-4 bg-green-50 border border-green-200">
                <p className="text-green-800 font-inter font-medium">
                  Great job! You've successfully used the calculator.
                  {isCompleted && " ✓ Lesson completed!"}
                </p>
              </div>
            )}
          </div>

          {/* Navigation */}
          {isCompleted && (
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
              <button onClick={onPrevPage} className="btn-secondary" aria-label="Go to previous lesson">
                ← Previous Lesson
              </button>
              <button onClick={onNextPage} className="btn-primary" aria-label="Go to next lesson">
                Next Lesson →
              </button>
            </div>
          )}
        </div>
      </div>
    )
  },
)

Page4_Calculator.displayName = "Page4_Calculator"
