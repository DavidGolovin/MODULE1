"use client"

import { memo, useState, useCallback, useMemo } from "react"
import { PageContainer } from "./page-container"
import { EnhancedCard } from "./enhanced-card"
import { EnhancedButton } from "./enhanced-button"
import { InfoModal } from "./info-modal"
import { SuccessBurst } from "./success-burst"
import { FloatingElements } from "./floating-elements"
import { Layout, Layers, CheckCircle, Code2 } from "lucide-react"

export const Page3_HtmlStructure = memo(() => {
  const [showModal, setShowModal] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [selectedStructure, setSelectedStructure] = useState<string | null>(null)
  const [completedSections, setCompletedSections] = useState<Set<string>>(new Set())

  const semanticElements = useMemo(
    () => [
      {
        id: "header",
        tag: "<header>",
        description: "Contains introductory content or navigation",
        usage: "Site header, article header, section header",
        example: "<header>\n  <h1>Site Title</h1>\n  <nav>Navigation</nav>\n</header>",
      },
      {
        id: "nav",
        tag: "<nav>",
        description: "Contains navigation links",
        usage: "Main navigation, breadcrumbs, pagination",
        example:
          '<nav>\n  <ul>\n    <li><a href="#home">Home</a></li>\n    <li><a href="#about">About</a></li>\n  </ul>\n</nav>',
      },
      {
        id: "main",
        tag: "<main>",
        description: "Contains the main content of the page",
        usage: "Primary content area (only one per page)",
        example: "<main>\n  <article>Main content here</article>\n</main>",
      },
      {
        id: "article",
        tag: "<article>",
        description: "Self-contained, reusable content",
        usage: "Blog posts, news articles, forum posts",
        example: "<article>\n  <h2>Article Title</h2>\n  <p>Article content...</p>\n</article>",
      },
      {
        id: "section",
        tag: "<section>",
        description: "Thematic grouping of content",
        usage: "Chapters, tabs, themed content areas",
        example: "<section>\n  <h2>Section Title</h2>\n  <p>Section content...</p>\n</section>",
      },
      {
        id: "aside",
        tag: "<aside>",
        description: "Content related to main content",
        usage: "Sidebars, pull quotes, advertisements",
        example: "<aside>\n  <h3>Related Links</h3>\n  <ul>...</ul>\n</aside>",
      },
      {
        id: "footer",
        tag: "<footer>",
        description: "Contains footer information",
        usage: "Site footer, article footer, section footer",
        example: "<footer>\n  <p>&copy; 2024 Company Name</p>\n</footer>",
      },
    ],
    [],
  )

  const documentStructure = useMemo(
    () => `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semantic HTML Structure</title>
</head>
<body>
    <header>
        <h1>My Website</h1>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <article>
            <header>
                <h2>Article Title</h2>
                <p>Published on <time datetime="2024-01-01">January 1, 2024</time></p>
            </header>
            <section>
                <h3>Introduction</h3>
                <p>Article introduction...</p>
            </section>
            <section>
                <h3>Main Content</h3>
                <p>Main article content...</p>
            </section>
        </article>
        
        <aside>
            <h3>Related Articles</h3>
            <ul>
                <li><a href="#">Related Article 1</a></li>
                <li><a href="#">Related Article 2</a></li>
            </ul>
        </aside>
    </main>
    
    <footer>
        <p>&copy; 2024 My Website. All rights reserved.</p>
    </footer>
</body>
</html>`,
    [],
  )

  const handleOpenModal = useCallback(() => {
    setShowModal(true)
  }, [])

  const handleCloseModal = useCallback(() => {
    setShowModal(false)
  }, [])

  const handleElementSelect = useCallback((elementId: string) => {
    setSelectedStructure(elementId)
    setCompletedSections((prev) => new Set([...prev, elementId]))
    setShowSuccess(true)
  }, [])

  const isCompleted = useCallback(
    (elementId: string) => {
      return completedSections.has(elementId)
    },
    [completedSections],
  )

  const selectedElement = useMemo(() => {
    return semanticElements.find((el) => el.id === selectedStructure)
  }, [semanticElements, selectedStructure])

  return (
    <PageContainer title="HTML Document Structure" subtitle="Learn how to organize content with semantic HTML elements">
      <FloatingElements />

      <div className="space-y-8">
        {/* Introduction */}
        <EnhancedCard className="animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-roots-primary-accent rounded-xl">
              <Layout className="w-8 h-8 text-roots-text" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-roots-text mb-3 font-inter">Why Document Structure Matters</h2>
              <p className="text-roots-dark-gray mb-4 font-inter leading-relaxed">
                Proper HTML structure makes your content accessible to screen readers, search engines, and other tools.
                Semantic elements describe the meaning of content, not just its appearance.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">Accessibility</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Screen readers understand content</p>
                </div>
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">SEO</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Search engines rank better</p>
                </div>
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">Maintenance</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Code is easier to understand</p>
                </div>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Semantic Elements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {semanticElements.map((element, index) => (
            <EnhancedCard
              key={element.id}
              className={`cursor-pointer transition-all duration-300 animate-fade-in-up ${
                selectedStructure === element.id ? "ring-2 ring-roots-primary-accent" : ""
              } ${isCompleted(element.id) ? "bg-green-50 border-green-200" : ""}`}
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => handleElementSelect(element.id)}
            >
              <div className="flex items-center justify-between mb-3">
                <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded font-mono text-sm">
                  {element.tag}
                </code>
                {isCompleted(element.id) && <CheckCircle className="w-5 h-5 text-green-500" />}
              </div>
              <h4 className="font-bold text-roots-text mb-2 font-inter">{element.description}</h4>
              <p className="text-sm text-roots-dark-gray font-inter mb-3">{element.usage}</p>
              <div className="text-xs text-roots-icon-color font-inter">Click to see example →</div>
            </EnhancedCard>
          ))}
        </div>

        {/* Selected Element Details */}
        {selectedElement && (
          <EnhancedCard className="animate-scale-up">
            <div className="flex items-center gap-3 mb-4">
              <Code2 className="w-6 h-6 text-roots-icon-color" />
              <h3 className="text-xl font-bold text-roots-text font-inter">{selectedElement.tag} Element Example</h3>
            </div>
            <div className="bg-roots-container-bg p-4 rounded-lg mb-4">
              <pre className="text-sm font-mono text-roots-text overflow-x-auto whitespace-pre-wrap">
                {selectedElement.example}
              </pre>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-bold text-roots-text mb-2 font-inter">Description:</h4>
                <p className="text-sm text-roots-dark-gray font-inter">{selectedElement.description}</p>
              </div>
              <div>
                <h4 className="font-bold text-roots-text mb-2 font-inter">Common Usage:</h4>
                <p className="text-sm text-roots-dark-gray font-inter">{selectedElement.usage}</p>
              </div>
            </div>
          </EnhancedCard>
        )}

        {/* Complete Document Structure */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
          <div className="flex items-center gap-3 mb-6">
            <Layers className="w-6 h-6 text-roots-icon-color" />
            <h3 className="text-xl font-bold text-roots-text font-inter">Complete Document Structure</h3>
          </div>
          <p className="text-roots-dark-gray mb-4 font-inter">
            Here's how all semantic elements work together in a complete HTML document:
          </p>
          <div className="bg-roots-container-bg p-4 rounded-lg mb-4 max-h-96 overflow-y-auto">
            <pre className="text-xs font-mono text-roots-text whitespace-pre-wrap">{documentStructure}</pre>
          </div>
          <div className="flex gap-3">
            <EnhancedButton onClick={handleOpenModal}>View Structure Guide</EnhancedButton>
            <EnhancedButton variant="secondary" onClick={() => navigator.clipboard.writeText(documentStructure)}>
              Copy Code
            </EnhancedButton>
          </div>
        </EnhancedCard>

        {/* Best Practices */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "1s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">HTML Structure Best Practices</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="card-container p-3">
                <h4 className="font-bold text-roots-text font-inter text-sm mb-2">✓ Do This</h4>
                <ul className="text-xs text-roots-text font-inter space-y-1">
                  <li>• Use semantic elements for their intended purpose</li>
                  <li>• Include only one &lt;main&gt; element per page</li>
                  <li>• Nest elements properly and consistently</li>
                  <li>• Use headings in hierarchical order (h1, h2, h3...)</li>
                  <li>• Include alt attributes for all images</li>
                  <li>• Use &lt;nav&gt; for navigation menus</li>
                </ul>
              </div>
            </div>
            <div>
              <div className="card-container p-3">
                <h4 className="font-bold text-roots-text font-inter text-sm mb-2">✗ Avoid This</h4>
                <ul className="text-xs text-roots-text font-inter space-y-1">
                  <li>• Using &lt;div&gt; for everything</li>
                  <li>• Skipping heading levels (h1 to h3)</li>
                  <li>• Multiple &lt;main&gt; elements on one page</li>
                  <li>• Using elements just for styling</li>
                  <li>• Forgetting closing tags</li>
                  <li>• Improper nesting of elements</li>
                </ul>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <EnhancedButton size="lg" variant="success">
            Practice with Exercise
          </EnhancedButton>
          <EnhancedButton size="lg">Continue to Forms</EnhancedButton>
        </div>
      </div>

      {/* Structure Guide Modal */}
      <InfoModal isOpen={showModal} onClose={handleCloseModal} title="HTML Document Structure Guide">
        <div className="space-y-6">
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Document Flow</h4>
            <div className="space-y-2 text-sm text-roots-dark-gray font-inter">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-roots-primary-accent rounded"></div>
                <span>
                  <strong>&lt;header&gt;</strong> - Top of page/section
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-roots-icon-color rounded"></div>
                <span>
                  <strong>&lt;nav&gt;</strong> - Navigation links
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span>
                  <strong>&lt;main&gt;</strong> - Primary content
                </span>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <div className="w-4 h-4 bg-blue-500 rounded"></div>
                <span>
                  <strong>&lt;article&gt;</strong> - Self-contained content
                </span>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <div className="w-4 h-4 bg-purple-500 rounded"></div>
                <span>
                  <strong>&lt;section&gt;</strong> - Thematic content
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-orange-500 rounded"></div>
                <span>
                  <strong>&lt;aside&gt;</strong> - Related content
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-gray-500 rounded"></div>
                <span>
                  <strong>&lt;footer&gt;</strong> - Bottom of page/section
                </span>
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Accessibility Benefits</h4>
            <ul className="space-y-1 text-sm text-roots-dark-gray font-inter">
              <li>• Screen readers can navigate by landmarks</li>
              <li>• Users can skip to main content</li>
              <li>• Content relationships are clear</li>
              <li>• Search engines understand page structure</li>
            </ul>
          </div>
        </div>
      </InfoModal>

      <SuccessBurst
        show={showSuccess}
        message="Great! You're learning semantic HTML structure!"
        onComplete={() => setShowSuccess(false)}
      />
    </PageContainer>
  )
})

Page3_HtmlStructure.displayName = "Page3_HtmlStructure"
