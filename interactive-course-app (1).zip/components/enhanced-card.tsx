"use client"

import { memo, type ReactNode } from "react"

interface EnhancedCardProps {
  children: ReactNode
  className?: string
  hover?: boolean
  onClick?: () => void
}

export const EnhancedCard = memo<EnhancedCardProps>(({ children, className = "", hover = true, onClick }) => {
  return (
    <div
      className={`
        global-container p-6
        ${hover ? "hover:shadow-lg hover:-translate-y-1" : ""}
        ${onClick ? "cursor-pointer" : ""}
        transition-all duration-300
        ${className}
      `}
      onClick={onClick}
    >
      {children}
    </div>
  )
})

EnhancedCard.displayName = "EnhancedCard"
