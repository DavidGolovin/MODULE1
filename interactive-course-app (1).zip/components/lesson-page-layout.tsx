"use client"

import { memo, type ReactNode } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface LessonPageLayoutProps {
  moduleTitle: string
  lessonTitle: string
  currentLesson: number
  totalLessons: number
  completedLessons: number
  children: ReactNode
  previousLessonHref?: string
  nextLessonHref?: string
  previousLessonTitle?: string
  nextLessonTitle?: string
  canGoBack?: boolean
  canGoForward?: boolean
  onPreviousLesson?: () => void
  onNextLesson?: () => void
}

const getEstimatedTime = (lessonNumber: number): number => {
  // All lessons now estimated at 45 seconds
  return 45
}

export const LessonPageLayout = memo<LessonPageLayoutProps>(
  ({
    moduleTitle,
    lessonTitle,
    currentLesson,
    totalLessons,
    completedLessons,
    children,
    previousLessonHref,
    nextLessonHref,
    previousLessonTitle,
    nextLessonTitle,
    canGoBack = true,
    canGoForward = true,
    onPreviousLesson,
    onNextLesson,
  }) => {
    const progressPercentage = (completedLessons / totalLessons) * 100
    const estimatedTime = getEstimatedTime(currentLesson)

    return (
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Module Title */}
              <div className="flex-1 min-w-0">
                <h2 className="text-lg font-semibold text-[#303030] truncate font-inter">{moduleTitle}</h2>
                <p className="text-sm text-[#303030] hidden sm:block font-inter">
                  Lesson {currentLesson} of {totalLessons} • {estimatedTime}s
                </p>
              </div>

              {/* Compact Progress Bar */}
              <div className="flex items-center space-x-4 ml-4">
                <div className="hidden sm:flex items-center space-x-2">
                  <span className="text-sm text-[#303030] whitespace-nowrap font-inter">
                    {Math.round(progressPercentage)}% Complete
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="w-32 sm:w-48">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-200 h-2">
                      <div
                        className="bg-[#303030] h-2 transition-all duration-500 ease-out"
                        style={{ width: `${progressPercentage}%` }}
                        role="progressbar"
                        aria-valuenow={progressPercentage}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-label={`Course progress: ${Math.round(progressPercentage)}% complete`}
                      />
                    </div>
                    <span className="text-xs text-[#303030] sm:hidden font-inter">
                      {Math.round(progressPercentage)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            {/* Lesson Title */}
            <div className="mb-8">
              <h1 className="text-3xl sm:text-4xl font-bold text-[#303030] leading-tight mb-4 font-inter">
                {lessonTitle}
              </h1>
              <div className="flex items-center space-x-4 text-sm text-[#303030] font-inter">
                <span>Lesson {currentLesson}</span>
                <span>•</span>
                <span>
                  {completedLessons} of {totalLessons} completed
                </span>
                <span>•</span>
                <span>{estimatedTime} seconds</span>
              </div>
            </div>

            {/* Lesson Content */}
            <div className="prose prose-lg max-w-none">{children}</div>
          </div>
        </main>

        {/* Bottom Navigation */}
        <footer className="bg-white border-t border-gray-200 py-6 px-4 sm:px-6 lg:px-8 shadow-sm">
          <div className="max-w-3xl mx-auto">
            <nav className="flex flex-col sm:flex-row sm:justify-between space-y-4 sm:space-y-0 sm:space-x-4">
              {/* Previous Lesson Button */}
              <div className="flex-1">
                {canGoBack && (previousLessonHref || onPreviousLesson) ? (
                  previousLessonHref ? (
                    <Link
                      href={previousLessonHref}
                      className="group flex items-center justify-center sm:justify-start w-full px-6 py-3 bg-[#303030] hover:bg-gray-800 text-[#CDFF64] font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#303030] focus:ring-offset-2 font-inter shadow-sm"
                    >
                      <ChevronLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform duration-200" />
                      <div className="text-left">
                        <div className="text-sm opacity-90">Previous</div>
                        <div className="font-semibold truncate">
                          {previousLessonTitle || `Lesson ${currentLesson - 1}`}
                        </div>
                      </div>
                    </Link>
                  ) : (
                    <button
                      onClick={onPreviousLesson}
                      className="group flex items-center justify-center sm:justify-start w-full px-6 py-3 bg-[#303030] hover:bg-gray-800 text-[#CDFF64] font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#303030] focus:ring-offset-2 font-inter shadow-sm"
                    >
                      <ChevronLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform duration-200" />
                      <div className="text-left">
                        <div className="text-sm opacity-90">Previous</div>
                        <div className="font-semibold">{previousLessonTitle || `Lesson ${currentLesson - 1}`}</div>
                      </div>
                    </button>
                  )
                ) : (
                  <div className="w-full px-6 py-3 bg-gray-100 text-gray-400 font-medium cursor-not-allowed flex items-center justify-center sm:justify-start font-inter shadow-sm">
                    <ChevronLeft className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div className="text-sm">Previous</div>
                      <div className="font-semibold">No previous lesson</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Next Lesson Button */}
              <div className="flex-1">
                {canGoForward && (nextLessonHref || onNextLesson) ? (
                  nextLessonHref ? (
                    <Link
                      href={nextLessonHref}
                      className="group flex items-center justify-center sm:justify-end w-full px-6 py-3 bg-[#303030] hover:bg-gray-800 text-[#CDFF64] font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#303030] focus:ring-offset-2 font-inter shadow-sm"
                    >
                      <div className="text-right">
                        <div className="text-sm opacity-90">Next</div>
                        <div className="font-semibold truncate">{nextLessonTitle || `Lesson ${currentLesson + 1}`}</div>
                      </div>
                      <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                    </Link>
                  ) : (
                    <button
                      onClick={onNextLesson}
                      className="group flex items-center justify-center sm:justify-end w-full px-6 py-3 bg-[#303030] hover:bg-gray-800 text-[#CDFF64] font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#303030] focus:ring-offset-2 font-inter shadow-sm"
                    >
                      <div className="text-right">
                        <div className="text-sm opacity-90">Next</div>
                        <div className="font-semibold">{nextLessonTitle || `Lesson ${currentLesson + 1}`}</div>
                      </div>
                      <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                    </button>
                  )
                ) : (
                  <div className="w-full px-6 py-3 bg-gray-100 text-gray-400 font-medium cursor-not-allowed flex items-center justify-center sm:justify-end font-inter shadow-sm">
                    <div className="text-right">
                      <div className="text-sm">Next</div>
                      <div className="font-semibold">Course complete</div>
                    </div>
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </div>
                )}
              </div>
            </nav>
          </div>
        </footer>
      </div>
    )
  },
)

LessonPageLayout.displayName = "LessonPageLayout"
