"use client"

import { memo } from "react"

interface CourseHeaderProps {
  title: string
  subtitle: string
}

export const CourseHeader = memo<CourseHeaderProps>(({ title, subtitle }) => {
  return (
    <header className="bg-roots-container-bg border-b border-roots-border-line">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-roots-text font-inter">{title}</h1>
          <p className="text-xl text-roots-dark-gray font-inter max-w-3xl mx-auto">{subtitle}</p>
        </div>
      </div>
    </header>
  )
})

CourseHeader.displayName = "CourseHeader"
