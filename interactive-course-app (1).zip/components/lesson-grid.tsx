"use client"

import { memo } from "react"

interface LessonGridProps {
  currentLesson: number
  completedLessons: Set<number>
  onLessonSelect: (lessonNumber: number) => void
}

const lessons = [
  { id: 1, title: "Welcome", description: "Get started with HTML fundamentals" },
  { id: 2, title: "HTML Basics", description: "Learn the basic structure of HTML" },
  { id: 3, title: "HTML Structure", description: "Understanding document structure" },
  { id: 4, title: "HTML Forms", description: "Creating interactive forms" },
  { id: 5, title: "HTML Tables", description: "Organizing data with tables" },
  { id: 6, title: "Semantic HTML", description: "Writing meaningful markup" },
  { id: 7, title: "HTML Best Practices", description: "Professional HTML techniques" },
  { id: 8, title: "Final Project", description: "Apply everything you've learned" },
]

export const LessonGrid = memo<LessonGridProps>(({ currentLesson, completedLessons, onLessonSelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {lessons.map((lesson) => {
        const isActive = lesson.id === currentLesson
        const isCompleted = completedLessons.has(lesson.id)
        const isAccessible = lesson.id === 1 || completedLessons.has(lesson.id - 1) || lesson.id <= currentLesson

        return (
          <button
            key={lesson.id}
            onClick={() => isAccessible && onLessonSelect(lesson.id)}
            disabled={!isAccessible}
            className={`lesson-card text-left transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary ${
              isActive ? "active" : ""
            } ${isCompleted ? "completed" : ""} ${!isAccessible ? "opacity-50 cursor-not-allowed" : "hover:shadow-md"}`}
            aria-current={isActive ? "page" : undefined}
            aria-disabled={!isAccessible}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-500 font-inter">
                  {lesson.id.toString().padStart(2, "0")}
                </span>
                {isCompleted && (
                  <div className="w-5 h-5 bg-primary text-accent flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                )}
              </div>
              {isActive && <div className="w-2 h-2 bg-primary animate-pulse" />}
            </div>

            <h3 className="text-lg font-semibold text-primary mb-2 font-inter">{lesson.title}</h3>
            <p className="text-sm text-gray-600 font-inter">{lesson.description}</p>

            {!isAccessible && lesson.id > 1 && (
              <div className="mt-2 text-xs text-gray-400 font-inter">Complete previous lesson to unlock</div>
            )}
          </button>
        )
      })}
    </div>
  )
})

LessonGrid.displayName = "LessonGrid"
