"use client"

import { memo, type ReactNode } from "react"
import Image from "next/image"

interface LessonContentProps {
  children?: ReactNode
}

interface LessonSectionProps {
  title?: string
  children: ReactNode
  className?: string
}

interface LessonImageProps {
  src: string
  alt: string
  caption?: string
  width?: number
  height?: number
}

interface LessonListProps {
  items: string[]
  ordered?: boolean
  className?: string
}

export const LessonContent = memo<LessonContentProps>(({ children }) => {
  return <div className="space-y-8">{children}</div>
})

export const LessonSection = memo<LessonSectionProps>(({ title, children, className = "" }) => {
  return (
    <section className={`space-y-4 ${className}`}>
      {title && <h2 className="text-2xl font-bold text-gray-900 border-b border-gray-200 pb-2">{title}</h2>}
      <div className="space-y-4">{children}</div>
    </section>
  )
})

export const LessonParagraph = memo<{ children: ReactNode; className?: string }>(({ children, className = "" }) => {
  return <p className={`text-lg leading-relaxed text-gray-700 ${className}`}>{children}</p>
})

export const LessonImage = memo<LessonImageProps>(({ src, alt, caption, width = 800, height = 400 }) => {
  return (
    <figure className="my-8">
      <div className="relative rounded-lg overflow-hidden shadow-lg bg-gray-100">
        <Image
          src={src || "/placeholder.svg"}
          alt={alt}
          width={width}
          height={height}
          className="w-full h-auto object-cover"
          priority={false}
        />
      </div>
      {caption && <figcaption className="mt-3 text-sm text-gray-600 text-center italic">{caption}</figcaption>}
    </figure>
  )
})

export const LessonList = memo<LessonListProps>(({ items, ordered = false, className = "" }) => {
  const ListComponent = ordered ? "ol" : "ul"
  const listClass = ordered ? "list-decimal list-inside space-y-2" : "list-disc list-inside space-y-2"

  return (
    <ListComponent className={`${listClass} text-lg text-gray-700 ${className}`}>
      {items.map((item, index) => (
        <li key={index} className="leading-relaxed">
          {item}
        </li>
      ))}
    </ListComponent>
  )
})

export const LessonHighlight = memo<{ children: ReactNode; variant?: "info" | "warning" | "success" }>(
  ({ children, variant = "info" }) => {
    const variantClasses = {
      info: "bg-blue-50 border-blue-200 text-blue-800",
      warning: "bg-yellow-50 border-yellow-200 text-yellow-800",
      success: "bg-green-50 border-green-200 text-green-800",
    }

    return (
      <div className={`p-4 rounded-lg border-l-4 ${variantClasses[variant]}`}>
        <div className="text-lg leading-relaxed">{children}</div>
      </div>
    )
  },
)

export const LessonQuote = memo<{ children: ReactNode; author?: string }>(({ children, author }) => {
  return (
    <blockquote className="border-l-4 border-green-500 pl-6 py-4 my-6 bg-gray-50 rounded-r-lg">
      <div className="text-xl italic text-gray-700 leading-relaxed">"{children}"</div>
      {author && <cite className="block mt-3 text-sm text-gray-600 font-medium">— {author}</cite>}
    </blockquote>
  )
})

LessonContent.displayName = "LessonContent"
LessonSection.displayName = "LessonSection"
LessonParagraph.displayName = "LessonParagraph"
LessonImage.displayName = "LessonImage"
LessonList.displayName = "LessonList"
LessonHighlight.displayName = "LessonHighlight"
LessonQuote.displayName = "LessonQuote"
