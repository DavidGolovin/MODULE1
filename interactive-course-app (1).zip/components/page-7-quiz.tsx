"use client"

import { useState, useCallback, useMemo } from "react"

interface Page7Props {
  onAllTrueFalseAnswered: () => void
  onNextPage: () => void
  onPrevPage: () => void
  isCompleted: boolean
}

interface QuizQuestion {
  id: number
  question: string
  options: string[]
  correctAnswer: number
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What does HTML stand for?",
    options: [
      "HyperText Markup Language",
      "High Tech Modern Language",
      "Home Tool Markup Language",
      "Hyperlink and Text Markup Language",
    ],
    correctAnswer: 0,
  },
  {
    id: 2,
    question: "Which HTML tag is used to define an internal style sheet?",
    options: ["<css>", "<style>", "<script>", "<link>"],
    correctAnswer: 1,
  },
  {
    id: 3,
    question: "What is the correct HTML element for the largest heading?",
    options: ["<heading>", "<h6>", "<h1>", "<head>"],
    correctAnswer: 2,
  },
  {
    id: 4,
    question: "Which attribute is used to provide a unique identifier for an HTML element?",
    options: ["class", "name", "id", "key"],
    correctAnswer: 2,
  },
  {
    id: 5,
    question: "What is the correct HTML for creating a hyperlink?",
    options: [
      "<a url='http://www.example.com'>Example</a>",
      "<a href='http://www.example.com'>Example</a>",
      "<a>http://www.example.com</a>",
      "<a name='http://www.example.com'>Example</a>",
    ],
    correctAnswer: 1,
  },
]

export const Page7_Quiz = ({ onAllTrueFalseAnswered, onNextPage, onPrevPage, isCompleted }: Page7Props) => {
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({})
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)

  const handleAnswerChange = useCallback((questionId: number, answerIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: answerIndex,
    }))
  }, [])

  const allQuestionsAnswered = useMemo(() => {
    return Object.keys(selectedAnswers).length === quizQuestions.length
  }, [selectedAnswers])

  const handleSubmit = useCallback(() => {
    let correctCount = 0
    quizQuestions.forEach((question) => {
      if (selectedAnswers[question.id] === question.correctAnswer) {
        correctCount++
      }
    })
    setScore(correctCount)
    setShowResults(true)
    onAllTrueFalseAnswered()
  }, [selectedAnswers, onAllTrueFalseAnswered])

  const resetQuiz = useCallback(() => {
    setSelectedAnswers({})
    setShowResults(false)
    setScore(0)
  }, [])

  return (
    <div className="min-h-screen bg-white font-inter">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-primary font-inter mb-4">HTML Knowledge Quiz</h1>
          <p className="text-lg text-primary font-inter">
            Test your understanding of HTML fundamentals with this interactive quiz.
          </p>
        </header>

        <main>
          {!showResults ? (
            <>
              {/* Quiz Questions */}
              <div className="space-y-6">
                {quizQuestions.map((question) => (
                  <div key={question.id} className="global-container p-6">
                    <h3 className="text-lg font-bold text-primary font-inter mb-4">
                      {question.id}. {question.question}
                    </h3>
                    <div className="space-y-3">
                      {question.options.map((option, index) => (
                        <label
                          key={index}
                          className="flex items-center space-x-3 cursor-pointer p-3 hover:bg-gray-50 transition-colors focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2"
                        >
                          <input
                            type="radio"
                            name={`question-${question.id}`}
                            value={index}
                            checked={selectedAnswers[question.id] === index}
                            onChange={() => handleAnswerChange(question.id, index)}
                            className="w-4 h-4 text-primary focus:ring-primary focus:ring-2"
                            aria-describedby={`question-${question.id}-option-${index}`}
                          />
                          <span id={`question-${question.id}-option-${index}`} className="text-primary font-inter">
                            {option}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Submit Button */}
              <div className="text-center mt-8">
                <button
                  onClick={handleSubmit}
                  disabled={!allQuestionsAnswered}
                  className={`px-8 py-3 font-inter font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                    allQuestionsAnswered
                      ? "bg-primary text-accent hover:bg-gray-800 focus:ring-primary cursor-pointer"
                      : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
                  aria-label={allQuestionsAnswered ? "Submit quiz answers" : "Answer all questions to submit"}
                >
                  Submit Quiz
                </button>
                <p className="text-sm text-primary font-inter mt-2">
                  {Object.keys(selectedAnswers).length}/{quizQuestions.length} questions answered
                </p>
              </div>
            </>
          ) : (
            /* Results */
            <div className="global-container p-8 text-center">
              <h2 className="text-2xl font-bold text-primary font-inter mb-4">Quiz Results</h2>
              <div className="text-4xl font-bold text-primary font-inter mb-4">
                {score}/{quizQuestions.length}
              </div>
              <p className="text-lg text-primary font-inter mb-6">
                You scored {Math.round((score / quizQuestions.length) * 100)}%
              </p>

              {/* Detailed Results */}
              <div className="space-y-4 mb-8 text-left">
                {quizQuestions.map((question) => {
                  const userAnswer = selectedAnswers[question.id]
                  const isCorrect = userAnswer === question.correctAnswer

                  return (
                    <div key={question.id} className="border border-gray-200 p-4 bg-white">
                      <h4 className="font-bold text-primary font-inter mb-2">
                        {question.id}. {question.question}
                      </h4>
                      <p className={`font-inter ${isCorrect ? "text-green-600" : "text-red-600"}`}>
                        Your answer: {question.options[userAnswer]} {isCorrect ? "✓" : "✗"}
                      </p>
                      {!isCorrect && (
                        <p className="text-green-600 font-inter">
                          Correct answer: {question.options[question.correctAnswer]}
                        </p>
                      )}
                    </div>
                  )
                })}
              </div>

              <button
                onClick={resetQuiz}
                className="bg-primary text-accent px-6 py-2 font-inter font-semibold hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 mr-4"
                aria-label="Retake the quiz"
              >
                Retake Quiz
              </button>
            </div>
          )}
        </main>

        {/* Navigation */}
        {(showResults || isCompleted) && (
          <nav
            className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200"
            role="navigation"
            aria-label="Lesson navigation"
          >
            <button
              onClick={onPrevPage}
              className="bg-primary text-accent px-6 py-2 font-inter font-semibold hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              aria-label="Go to previous lesson"
            >
              ← Previous Lesson
            </button>
            <button
              onClick={onNextPage}
              className="bg-primary text-accent px-6 py-2 font-inter font-semibold hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              aria-label="Go to next lesson"
            >
              Next Lesson →
            </button>
          </nav>
        )}
      </div>
    </div>
  )
}
