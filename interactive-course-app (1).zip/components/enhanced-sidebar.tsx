"use client"
import { useEnhancedProgressTracking } from "../hooks/use-enhanced-progress-tracking"

interface SidebarItem {
  id: number
  title: string
  completed?: boolean
}

interface EnhancedSidebarProps {
  isOpen: boolean
  onToggle: () => void
  className?: string
}

const lessons: SidebarItem[] = [
  { id: 1, title: "Welcome & Introduction" },
  { id: 2, title: "Market Overview" },
  { id: 3, title: "Market Trends Analysis" },
  { id: 4, title: "Down Payment Calculator" },
  { id: 5, title: "Win-Win Scenarios" },
  { id: 6, title: "Eligible Loan Programs" },
  { id: 7, title: "Knowledge Quiz" },
  { id: 8, title: "Application Process" },
]

export function EnhancedSidebar({ isOpen, onToggle, className = "" }: EnhancedSidebarProps) {
  const { currentLesson, completedLessons, navigateToLesson, isLessonCompleted } = useEnhancedProgressTracking()

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden" onClick={onToggle} aria-hidden="true" />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-80 theme-container border-r z-50 transform transition-transform duration-300 ease-in-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
          md:relative md:translate-x-0 md:z-auto
          ${className}
        `}
        role="navigation"
        aria-label="Course navigation"
      >
        {/* Header */}
        <div className="p-6 border-b">
          <div className="responsive-stack justify-between">
            <h2 className="text-xl font-bold">Course Navigation</h2>
            <button onClick={onToggle} className="md:hidden btn-secondary p-2" aria-label="Close navigation menu">
              ✕
            </button>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="p-4">
          <ul role="list" className="space-y-2">
            {lessons.map((lesson) => {
              const isActive = currentLesson === lesson.id
              const isCompleted = isLessonCompleted(lesson.id)

              return (
                <li key={lesson.id}>
                  <button
                    onClick={() => {
                      navigateToLesson(lesson.id)
                      onToggle() // Close mobile menu
                    }}
                    className={`
                      w-full text-left p-3 transition-all duration-200 border
                      ${isActive ? "theme-active font-bold" : "hover:bg-gray-50 border-transparent"}
                    `}
                    aria-current={isActive ? "page" : undefined}
                    aria-label={`Go to lesson ${lesson.id}: ${lesson.title}${isCompleted ? " (completed)" : ""}`}
                  >
                    <div className="responsive-stack">
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium">{lesson.id}</span>
                        <span className={isActive ? "font-bold" : ""}>{lesson.title}</span>
                      </div>
                      {isCompleted && (
                        <span className="text-sm badge" aria-label="Completed">
                          ✓
                        </span>
                      )}
                    </div>
                  </button>
                </li>
              )
            })}
          </ul>
        </nav>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t">
          <div className="text-sm text-center">
            <div className="font-medium mb-2">
              {Array.from(completedLessons).length} of {lessons.length} lessons completed
            </div>
          </div>
        </div>
      </aside>
    </>
  )
}
