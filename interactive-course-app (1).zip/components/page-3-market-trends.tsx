"use client"

import { memo, useRef, useEffect, useMemo, useState, useCallback } from "react"
import { EnhancedCard } from "./enhanced-card"
import { EnhancedButton } from "./enhanced-button"
import { Chart, type ChartConfiguration, registerables } from "chart.js"
import { Box, Typography, Grid, Paper } from "@mui/material"
import { createTheme, ThemeProvider } from "@mui/material/styles"
import { Inter } from "next/font/google"

// Register Chart.js components
Chart.register(...registerables)

interface MarketData {
  year: number
  rate: number
  marketCondition: string
  description: string
  assumableOpportunity: string
  marketSnapshot: {
    avgRate: number
    rateChange: string
    marketActivity: string
    assumableValue: string
  }
}

interface Page3_MarketTrendsProps {
  onNextPage?: () => void
  onPrevPage?: () => void
  onPageCompletion?: (completed: boolean) => void
  isCompleted?: boolean
}

const inter = Inter({ subsets: ["latin"] })

const theme = createTheme({
  palette: {
    mode: "dark", // Assuming a dark mode theme
    primary: {
      main: "#CDFF64", // Accent color
    },
    background: {
      default: "#121212", // Dark background
      paper: "#FFFFFF", // White background for containers
    },
    text: {
      primary: "#303030", // Text color
    },
  },
  typography: {
    fontFamily: inter.style.fontFamily,
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 0, // Square corners
          boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.1)", // Consistent shadow
          border: "1px solid #444444", // Subtle gray border
        },
      },
    },
  },
})

export const Page3_MarketTrends = memo<Page3_MarketTrendsProps>(
  ({ onNextPage, onPrevPage, onPageCompletion, isCompleted = false }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null)
    const chartRef = useRef<Chart | null>(null)
    const [selectedYear, setSelectedYear] = useState<number>(2024)
    const [exploredYears, setExploredYears] = useState<Set<number>>(new Set())
    const requiredYears = [2020, 2021, 2023, 2024] // Key years to explore

    // Historical market data
    const marketData = useMemo(
      (): MarketData[] => [
        {
          year: 2018,
          rate: 4.54,
          marketCondition: "Stable Growth",
          description: "Moderate rates with steady market activity",
          assumableOpportunity: "Limited opportunities as rates were rising",
          marketSnapshot: {
            avgRate: 4.54,
            rateChange: "+0.8% from 2017",
            marketActivity: "High",
            assumableValue: "Low",
          },
        },
        {
          year: 2019,
          rate: 3.94,
          marketCondition: "Buyer's Market",
          description: "Rates declined, creating favorable buying conditions",
          assumableOpportunity: "Emerging opportunities for future assumptions",
          marketSnapshot: {
            avgRate: 3.94,
            rateChange: "-0.6% from 2018",
            marketActivity: "Very High",
            assumableValue: "Moderate",
          },
        },
        {
          year: 2020,
          rate: 3.11,
          marketCondition: "Historic Lows",
          description: "Pandemic-driven rate cuts created unprecedented opportunities",
          assumableOpportunity: "Prime loans for future assumption candidates",
          marketSnapshot: {
            avgRate: 3.11,
            rateChange: "-0.83% from 2019",
            marketActivity: "Extremely High",
            assumableValue: "High",
          },
        },
        {
          year: 2021,
          rate: 2.96,
          marketCondition: "Record Lows",
          description: "Lowest rates in modern history fueled buying frenzy",
          assumableOpportunity: "Golden era for assumable loan creation",
          marketSnapshot: {
            avgRate: 2.96,
            rateChange: "-0.15% from 2020",
            marketActivity: "Peak",
            assumableValue: "Excellent",
          },
        },
        {
          year: 2022,
          rate: 5.34,
          marketCondition: "Rapid Rise",
          description: "Aggressive rate hikes to combat inflation",
          assumableOpportunity: "2020-2021 loans become highly valuable",
          marketSnapshot: {
            avgRate: 5.34,
            rateChange: "+2.38% from 2021",
            marketActivity: "Declining",
            assumableValue: "Very High",
          },
        },
        {
          year: 2023,
          rate: 6.81,
          marketCondition: "Elevated Rates",
          description: "Continued tightening created affordability challenges",
          assumableOpportunity: "Peak demand for low-rate assumptions",
          marketSnapshot: {
            avgRate: 6.81,
            rateChange: "+1.47% from 2022",
            marketActivity: "Low",
            assumableValue: "Exceptional",
          },
        },
        {
          year: 2024,
          rate: 6.62,
          marketCondition: "Stabilizing",
          description: "Slight moderation but still elevated compared to recent history",
          assumableOpportunity: "Strong market for assumable transactions",
          marketSnapshot: {
            avgRate: 6.62,
            rateChange: "-0.19% from 2023",
            marketActivity: "Moderate",
            assumableValue: "Very High",
          },
        },
        {
          year: 2025,
          rate: 6.25,
          marketCondition: "Projected Decline",
          description: "Expected gradual decline as economic conditions normalize",
          assumableOpportunity: "Continued strong demand for sub-4% assumptions",
          marketSnapshot: {
            avgRate: 6.25,
            rateChange: "-0.37% projected",
            marketActivity: "Improving",
            assumableValue: "High",
          },
        },
      ],
      [],
    )

    // Chart configuration
    const chartConfig = useMemo((): ChartConfiguration<"line"> => {
      const years = marketData.map((d) => d.year.toString())
      const rates = marketData.map((d) => d.rate)

      return {
        type: "line",
        data: {
          labels: years,
          datasets: [
            {
              label: "Average Mortgage Rate",
              data: rates,
              borderColor: "rgba(205, 255, 100, 1)",
              backgroundColor: "rgba(205, 255, 100, 0.1)",
              pointBackgroundColor: "rgba(205, 255, 100, 1)",
              pointBorderColor: "rgba(255, 255, 255, 1)",
              pointHoverBackgroundColor: "rgba(48, 48, 48, 1)",
              pointHoverBorderColor: "rgba(205, 255, 100, 1)",
              pointRadius: 6,
              pointHoverRadius: 8,
              borderWidth: 3,
              fill: true,
              tension: 0.4,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              backgroundColor: "rgba(255, 255, 255, 0.95)",
              titleColor: "rgba(48, 48, 48, 1)",
              bodyColor: "rgba(48, 48, 48, 1)",
              borderColor: "rgba(224, 224, 224, 1)",
              borderWidth: 1,
              titleFont: {
                family: "Inter, sans-serif",
                size: 14,
                weight: "bold",
              },
              bodyFont: {
                family: "Inter, sans-serif",
                size: 12,
              },
              callbacks: {
                title: (context) => {
                  const year = context[0].label
                  const data = marketData.find((d) => d.year.toString() === year)
                  return `${year} - ${data?.marketCondition || ""}`
                },
                label: (context) => {
                  return `Average Rate: ${context.parsed.y}%`
                },
              },
            },
          },
          scales: {
            x: {
              ticks: {
                color: "rgba(48, 48, 48, 1)",
                font: {
                  family: "Inter, sans-serif",
                  size: 12,
                },
              },
              grid: {
                color: "rgba(224, 224, 224, 0.3)",
              },
              border: {
                color: "rgba(224, 224, 224, 1)",
              },
              title: {
                display: true,
                text: "Year",
                color: "rgba(48, 48, 48, 1)",
                font: {
                  family: "Inter, sans-serif",
                  size: 14,
                  weight: "bold",
                },
              },
            },
            y: {
              beginAtZero: false,
              min: 2,
              max: 8,
              ticks: {
                color: "rgba(48, 48, 48, 1)",
                font: {
                  family: "Inter, sans-serif",
                  size: 12,
                },
                callback: (value) => `${value}%`,
              },
              grid: {
                color: "rgba(224, 224, 224, 0.5)",
              },
              border: {
                color: "rgba(224, 224, 224, 1)",
              },
              title: {
                display: true,
                text: "Interest Rate (%)",
                color: "rgba(48, 48, 48, 1)",
                font: {
                  family: "Inter, sans-serif",
                  size: 14,
                  weight: "bold",
                },
              },
            },
          },
        },
      }
    }, [marketData])

    // Create and destroy chart
    useEffect(() => {
      if (!canvasRef.current) return

      if (chartRef.current) {
        chartRef.current.destroy()
      }

      chartRef.current = new Chart(canvasRef.current, chartConfig)

      return () => {
        if (chartRef.current) {
          chartRef.current.destroy()
          chartRef.current = null
        }
      }
    }, [chartConfig])

    const handleYearSelect = useCallback(
      (year: number) => {
        setSelectedYear(year)
        const newExploredYears = new Set([...exploredYears, year])
        setExploredYears(newExploredYears)

        // Check if user has explored all required years
        const hasExploredRequired = requiredYears.every((reqYear) => newExploredYears.has(reqYear))
        if (hasExploredRequired && onPageCompletion) {
          onPageCompletion(true)
        }
      },
      [exploredYears, onPageCompletion],
    )

    const selectedData = useMemo(() => {
      return marketData.find((d) => d.year === selectedYear)
    }, [marketData, selectedYear])

    const handleNextPage = () => {
      if (isCompleted && onNextPage) {
        onNextPage()
      }
    }

    const handlePrevPage = () => {
      if (onPrevPage) {
        onPrevPage()
      }
    }

    const identificationTips = useMemo(
      () => [
        "Look for properties purchased between 2019-2021 when rates were at historic lows",
        "Focus on FHA, VA, and USDA loans - these are typically assumable",
        "Check public records for original loan dates and amounts",
        "Network with real estate agents who specialize in assumable properties",
        "Use online databases and MLS systems that flag assumable loans",
        "Contact lenders directly to verify assumption eligibility",
      ],
      [],
    )

    const commonMisconceptions = useMemo(
      () => [
        {
          myth: "All mortgages are assumable",
          reality: "Only government-backed loans (FHA, VA, USDA) and some portfolio loans are typically assumable",
        },
        {
          myth: "You automatically qualify if you can afford the payments",
          reality: "Lenders still require full qualification including credit, income, and debt-to-income verification",
        },
        {
          myth: "The original borrower is released from liability immediately",
          reality: "Release of liability requires separate approval and isn't guaranteed",
        },
        {
          myth: "Assumable loans are easy to find",
          reality: "They require specialized knowledge and often aren't advertised as assumable",
        },
      ],
      [],
    )

    return (
      <ThemeProvider theme={theme}>
        <Box sx={{ padding: 4, bgcolor: "background.default", color: "text.primary" }}>
          <Typography variant="h4" gutterBottom color="primary">
            Market Trends & Timing
          </Typography>

          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Why Market Timing Matters
                </Typography>
                <Typography variant="body1">
                  The value of assumable loans is directly tied to interest rate movements. When current market rates
                  are
                  <strong className="text-roots-text"> significantly higher</strong> than existing loan rates, assumable
                  mortgages become incredibly valuable assets.
                </Typography>
                <Typography variant="body1">
                  Understanding historical rate trends helps you identify the best opportunities and time your assumable
                  loan strategy for maximum benefit.
                </Typography>
              </Paper>
            </Grid>

            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Historical Interest Rate Trends
                </Typography>
                <div className="h-80 w-full mb-4">
                  <canvas ref={canvasRef} />
                </div>
                <Grid container spacing={2}>
                  <Grid item xs={6} md={3}>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="text-red-700">🔥</span>
                      <span className="font-bold text-roots-text font-inter">Peak Rates</span>
                    </div>
                    <Typography variant="body2" className="text-roots-dark-gray font-inter">
                      2023: 6.81%
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="text-blue-700">❄️</span>
                      <span className="font-bold text-roots-text font-inter">Historic Lows</span>
                    </div>
                    <Typography variant="body2" className="text-roots-dark-gray font-inter">
                      2021: 2.96%
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="text-roots-icon-color">📊</span>
                      <span className="font-bold text-roots-text font-inter">Rate Spread</span>
                    </div>
                    <Typography variant="body2" className="text-roots-dark-gray font-inter">
                      3.85% difference
                    </Typography>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <div className="flex items-center justify-center gap-2 mb-1">
                      <span className="text-green-700">💡</span>
                      <span className="font-bold text-roots-text font-inter">Opportunity</span>
                    </div>
                    <Typography variant="body2" className="text-roots-dark-gray font-inter">
                      2020-2021 loans
                    </Typography>
                  </Grid>
                </Grid>
              </Paper>
            </Grid>

            <Grid item xs={12}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Interactive Rate Explorer
                </Typography>
                <div className="space-y-6">
                  {/* Year Selection Buttons */}
                  <div className="flex flex-wrap gap-3 justify-center">
                    {marketData.map((data) => (
                      <EnhancedButton
                        key={data.year}
                        onClick={() => handleYearSelect(data.year)}
                        className={`transition-all duration-300 ${
                          selectedYear === data.year
                            ? "bg-roots-primary-accent text-roots-text shadow-lg scale-105"
                            : "bg-roots-container-bg text-roots-text hover:bg-roots-light-gray hover:scale-[1.02] border border-roots-border-line"
                        }`}
                      >
                        {data.year}
                      </EnhancedButton>
                    ))}
                  </div>

                  {/* Market Snapshot Card */}
                  {selectedData && (
                    <EnhancedCard className="bg-roots-container-bg border-roots-icon-color border-2">
                      <div className="flex items-center gap-3 mb-6">
                        <span className="text-2xl text-roots-icon-color">📊</span>
                        <Typography variant="h5" className="text-xl font-bold text-roots-text font-inter">
                          {selectedData.year} Market Snapshot
                        </Typography>
                      </div>

                      <Grid container spacing={2} mb={6}>
                        <Grid item xs={12} md={6} lg={3}>
                          <Paper elevation={3} sx={{ p: 2, textAlign: "center" }}>
                            <Typography
                              variant="h6"
                              className="text-2xl font-bold text-roots-primary-accent font-inter"
                            >
                              {selectedData.marketSnapshot.avgRate}%
                            </Typography>
                            <Typography variant="body2" className="text-sm text-roots-dark-gray font-inter">
                              Average Rate
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={12} md={6} lg={3}>
                          <Paper elevation={3} sx={{ p: 2, textAlign: "center" }}>
                            <Typography variant="h6" className="text-lg font-bold text-roots-text font-inter">
                              {selectedData.marketSnapshot.rateChange}
                            </Typography>
                            <Typography variant="body2" className="text-sm text-roots-dark-gray font-inter">
                              Rate Change
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={12} md={6} lg={3}>
                          <Paper elevation={3} sx={{ p: 2, textAlign: "center" }}>
                            <Typography variant="h6" className="text-lg font-bold text-roots-icon-color font-inter">
                              {selectedData.marketSnapshot.marketActivity}
                            </Typography>
                            <Typography variant="body2" className="text-sm text-roots-dark-gray font-inter">
                              Market Activity
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={12} md={6} lg={3}>
                          <Paper elevation={3} sx={{ p: 2, textAlign: "center" }}>
                            <Typography variant="h6" className="text-lg font-bold text-roots-primary-accent font-inter">
                              {selectedData.marketSnapshot.assumableValue}
                            </Typography>
                            <Typography variant="body2" className="text-sm text-roots-dark-gray font-inter">
                              Assumable Value
                            </Typography>
                          </Paper>
                        </Grid>
                      </Grid>

                      <div className="space-y-4">
                        <div>
                          <Typography variant="h6" className="font-bold text-roots-text font-inter mb-2">
                            Market Condition
                          </Typography>
                          <Typography variant="body2" className="text-roots-dark-gray font-inter">
                            {selectedData.description}
                          </Typography>
                        </div>
                        <div>
                          <Typography variant="h6" className="font-bold text-roots-text font-inter mb-2">
                            Assumable Opportunity
                          </Typography>
                          <Typography variant="body2" className="text-roots-dark-gray font-inter">
                            {selectedData.assumableOpportunity}
                          </Typography>
                        </div>
                      </div>
                    </EnhancedCard>
                  )}
                </div>
              </Paper>
            </Grid>

            <Grid item xs={12}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  How to Identify Assumable Opportunities
                </Typography>
                <Grid container spacing={3}>
                  {identificationTips.map((tip, index) => (
                    <Grid item xs={12} md={6} key={index}>
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-roots-primary-accent rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Typography variant="body2" className="text-xs font-bold text-roots-text font-inter">
                            {index + 1}
                          </Typography>
                        </div>
                        <Typography variant="body2" className="text-roots-dark-gray font-inter text-sm">
                          {tip}
                        </Typography>
                      </div>
                    </Grid>
                  ))}
                </Grid>
              </Paper>
            </Grid>

            <Grid item xs={12}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Common Misconceptions
                </Typography>
                <Grid container spacing={3}>
                  {commonMisconceptions.map((item, index) => (
                    <Grid item xs={12} md={6} key={index}>
                      <Paper elevation={3} sx={{ p: 2, borderLeft: "4px solid red" }}>
                        <div className="space-y-3">
                          <div>
                            <Typography variant="h6" className="font-bold text-red-600 font-inter mb-1">
                              ❌ Myth:
                            </Typography>
                            <Typography variant="body2" className="text-roots-dark-gray font-inter text-sm">
                              {item.myth}
                            </Typography>
                          </div>
                          <div>
                            <Typography variant="h6" className="font-bold text-green-600 font-inter mb-1">
                              ✅ Reality:
                            </Typography>
                            <Typography variant="body2" className="text-roots-dark-gray font-inter text-sm">
                              {item.reality}
                            </Typography>
                          </div>
                        </div>
                      </Paper>
                    </Grid>
                  ))}
                </Grid>
              </Paper>
            </Grid>

            <Grid item xs={12}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Next Steps
                </Typography>
                <div className="flex justify-between items-center pt-8 border-t border-roots-border-line">
                  <EnhancedButton variant="secondary" onClick={handlePrevPage}>
                    ← Previous: Introduction
                  </EnhancedButton>
                  <div className="flex flex-col items-end gap-2">
                    {!isCompleted && (
                      <div className="text-sm text-roots-dark-gray font-inter flex items-center gap-2">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
                        Explore years {requiredYears.filter((year) => !exploredYears.has(year)).join(", ")} to continue
                      </div>
                    )}
                    <EnhancedButton
                      onClick={handleNextPage}
                      size="lg"
                      disabled={!isCompleted}
                      className={!isCompleted ? "opacity-50 cursor-not-allowed" : ""}
                    >
                      {isCompleted ? (
                        <>
                          Next: Calculator → <span className="ml-2 text-green-500">✓</span>
                        </>
                      ) : (
                        "Next: Calculator →"
                      )}
                    </EnhancedButton>
                  </div>
                </div>
              </Paper>
            </Grid>
          </Grid>
        </Box>
      </ThemeProvider>
    )
  },
)

Page3_MarketTrends.displayName = "Page3_MarketTrends"
