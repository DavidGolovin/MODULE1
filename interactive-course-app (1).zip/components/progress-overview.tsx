"use client"

import { memo } from "react"
import { EnhancedCard } from "./enhanced-card"
import { TrendingUp, Clock, Award } from "lucide-react"

interface ProgressOverviewProps {
  progress: number
  completed: number
  total: number
  totalDuration: number
}

export const ProgressOverview = memo<ProgressOverviewProps>(({ progress, completed, total, totalDuration }) => {
  const formatDuration = (minutes: number): string => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }

  return (
    <EnhancedCard className="border-roots-primary-accent">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <TrendingUp className="w-6 h-6 text-roots-primary-accent" />
          <h2 className="text-xl font-bold text-roots-text font-inter">Your Learning Progress</h2>
        </div>

        {/* Progress Bar */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-roots-dark-gray font-inter">Course Completion</span>
            <span className="text-2xl font-bold text-roots-text font-inter">{Math.round(progress)}%</span>
          </div>

          <div className="progress-enhanced">
            <div className="progress-fill transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>

          <p className="text-sm text-roots-dark-gray font-inter">
            {completed} of {total} sections completed
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-roots-light-gray rounded-lg">
            <Clock className="w-5 h-5 text-roots-icon-color mx-auto mb-2" />
            <div className="text-lg font-bold text-roots-text font-inter">{formatDuration(totalDuration)}</div>
            <div className="text-sm text-roots-dark-gray font-inter">Total Duration</div>
          </div>

          <div className="text-center p-4 bg-roots-light-gray rounded-lg">
            <Award className="w-5 h-5 text-roots-primary-accent mx-auto mb-2" />
            <div className="text-lg font-bold text-roots-text font-inter">{completed}</div>
            <div className="text-sm text-roots-dark-gray font-inter">Completed</div>
          </div>
        </div>
      </div>
    </EnhancedCard>
  )
})

ProgressOverview.displayName = "ProgressOverview"
