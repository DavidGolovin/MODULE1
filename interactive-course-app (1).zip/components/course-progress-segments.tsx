"use client"

import { memo, useEffect, useState } from "react"

interface CourseProgressSegmentsProps {
  currentPage: number
  totalPages: number
  pageCompletions?: Record<number, boolean>
  className?: string
}

export const CourseProgressSegments = memo<CourseProgressSegmentsProps>(
  ({ currentPage, totalPages, pageCompletions, className = "" }) => {
    const [animatingSegment, setAnimatingSegment] = useState<number | null>(null)
    const [previousPage, setPreviousPage] = useState(currentPage)

    // Calculate completion percentage
    const completedPages = pageCompletions ? Object.values(pageCompletions).filter(Boolean).length : 0
    const progressPercentage = Math.round((completedPages / totalPages) * 100)

    // Handle animation when page changes
    useEffect(() => {
      if (currentPage !== previousPage) {
        setAnimatingSegment(currentPage)
        setPreviousPage(currentPage)

        // Clear animation after it completes
        const timer = setTimeout(() => {
          setAnimatingSegment(null)
        }, 600)

        return () => clearTimeout(timer)
      }
    }, [currentPage, previousPage])

    const getSegmentState = (segmentIndex: number): "completed" | "current" | "upcoming" => {
      const pageNumber = segmentIndex + 1

      if (pageCompletions?.[pageNumber]) {
        return "completed"
      } else if (pageNumber === currentPage) {
        return "current"
      } else {
        return "upcoming"
      }
    }

    const getSegmentTitle = (pageNumber: number): string => {
      const pageTitles: Record<number, string> = {
        1: "Welcome",
        2: "Introduction",
        3: "Market Trends",
        4: "Calculator",
        5: "Win-Win Scenarios",
        6: "Eligible Loans",
        7: "Quiz",
        8: "Process Steps",
        9: "Down Payment Gap",
        10: "Seller Risk",
        11: "Buyer Considerations",
        12: "Agent Role",
        13: "Case Study",
        14: "Glossary Game",
        15: "Conclusion",
      }
      return pageTitles[pageNumber] || `Lesson ${pageNumber}`
    }

    const getEstimatedPageTime = (pageNumber: number): number => {
      // All pages now have 45 second estimates
      const pageTimes: Record<number, number> = {
        1: 45, // Welcome
        2: 45, // Introduction
        3: 45, // Market Trends
        4: 45, // Calculator
        5: 45, // Win-Win Scenarios
        6: 45, // Eligible Loans
        7: 45, // Quiz
        8: 45, // Process Steps
        9: 45, // Down Payment Gap
        10: 45, // Seller Risk
        11: 45, // Buyer Considerations
        12: 45, // Agent Role
        13: 45, // Case Study
        14: 45, // Glossary Game
        15: 45, // Conclusion
      }
      return pageTimes[pageNumber] || 45
    }

    const calculateTotalEstimatedTime = (): number => {
      let totalTime = 0
      for (let i = 1; i <= totalPages; i++) {
        totalTime += getEstimatedPageTime(i)
      }
      return totalTime
    }

    const totalEstimatedTime = calculateTotalEstimatedTime()

    return (
      <div className={`w-full ${className}`}>
        {/* Native progress element for accessibility */}
        <progress
          value={completedPages}
          max={totalPages}
          className="sr-only"
          aria-label={`Course progress: ${progressPercentage}% complete`}
        />

        {/* Visual progress bar */}
        <div
          className="relative"
          role="progressbar"
          aria-valuenow={completedPages}
          aria-valuemin={0}
          aria-valuemax={totalPages}
          aria-label={`Course progress: ${progressPercentage}% complete`}
        >
          {/* Progress container */}
          <div className="flex w-full bg-gray-100 overflow-hidden border border-gray-200 shadow-sm">
            {Array.from({ length: totalPages }, (_, index) => {
              const segmentState = getSegmentState(index)
              const pageNumber = index + 1
              const isAnimating = animatingSegment === pageNumber

              return (
                <div
                  key={index}
                  className={`
                    flex-1 h-4 relative transition-all duration-500 ease-out
                    ${
                      segmentState === "completed"
                        ? "bg-[#303030]"
                        : segmentState === "current"
                          ? "bg-gray-400"
                          : "bg-gray-200"
                    }
                    ${isAnimating ? "animate-pulse scale-105" : ""}
                    ${index > 0 ? "border-l border-white" : ""}
                  `}
                  title={`${getSegmentTitle(pageNumber)} - ${
                    segmentState === "completed" ? "Completed" : segmentState === "current" ? "Current" : "Upcoming"
                  } (${getEstimatedPageTime(pageNumber)}s)`}
                >
                  {/* Segment fill animation */}
                  {segmentState === "completed" && (
                    <div
                      className={`
                        absolute inset-0 bg-gradient-to-r from-[#303030] to-gray-800
                        ${isAnimating ? "animate-segment-fill" : ""}
                      `}
                    />
                  )}

                  {/* Current segment pulse */}
                  {segmentState === "current" && (
                    <div className="absolute inset-0 bg-gradient-to-r from-gray-400 to-gray-500 animate-pulse" />
                  )}

                  {/* Segment number for larger screens */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span
                      className={`
                      text-xs font-bold hidden sm:block font-inter
                      ${segmentState === "completed" ? "text-[#CDFF64]" : segmentState === "current" ? "text-white" : "text-[#303030]"}
                    `}
                    >
                      {pageNumber}
                    </span>
                  </div>

                  {/* Completion checkmark */}
                  {segmentState === "completed" && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg className="w-3 h-3 text-[#CDFF64] animate-bounce-in" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Progress percentage label */}
          <div className="flex justify-between items-center mt-3">
            <div className="text-sm text-[#303030] font-inter">
              <span className="font-medium">{completedPages}</span> of {totalPages} lessons completed
            </div>
            <div className="text-lg font-bold text-[#303030] font-inter">{progressPercentage}% complete</div>
          </div>

          {/* Lesson titles for mobile */}
          <div className="mt-2 sm:hidden">
            <div className="text-xs text-[#303030] text-center font-inter">
              Current: {getSegmentTitle(currentPage)} ({getEstimatedPageTime(currentPage)}s)
            </div>
          </div>
        </div>

        {/* Detailed progress info */}
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div className="bg-white p-3 border border-gray-200 shadow-sm">
            <div className="text-2xl font-bold text-[#303030] font-inter">{completedPages}</div>
            <div className="text-xs text-[#303030] font-inter">Completed</div>
          </div>
          <div className="bg-white p-3 border border-gray-200 shadow-sm">
            <div className="text-2xl font-bold text-[#303030] font-inter">1</div>
            <div className="text-xs text-[#303030] font-inter">Current</div>
          </div>
          <div className="bg-white p-3 border border-gray-200 shadow-sm">
            <div className="text-2xl font-bold text-[#303030] font-inter">{totalPages - completedPages - 1}</div>
            <div className="text-xs text-[#303030] font-inter">Remaining</div>
          </div>
        </div>

        {/* Total time estimate */}
        <div className="mt-4 text-center">
          <div className="text-sm text-[#303030] font-inter">
            Total estimated time:{" "}
            <span className="font-medium">
              {Math.floor(totalEstimatedTime / 60)}m {totalEstimatedTime % 60}s
            </span>
          </div>
        </div>
      </div>
    )
  },
)

CourseProgressSegments.displayName = "CourseProgressSegments"
