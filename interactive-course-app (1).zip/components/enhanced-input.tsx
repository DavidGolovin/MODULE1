"use client"

import { memo, type InputHTMLAttributes } from "react"

interface EnhancedInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  className?: string
}

export const EnhancedInput = memo<EnhancedInputProps>(({ label, error, className = "", ...props }) => {
  return (
    <div className={`space-y-2 ${className}`}>
      {label && <label className="block text-sm font-medium">{label}</label>}
      <input
        className={`
          w-full px-3 py-2 transition-all duration-300
          ${error ? "border-red-500" : ""}
        `}
        {...props}
      />
      {error && <p className="text-sm text-red-500">{error}</p>}
    </div>
  )
})

EnhancedInput.displayName = "EnhancedInput"
