"use client"

import { useState } from "react"
import { GlossaryMatchingGame } from "./glossary-matching-game"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, RotateCcw } from "lucide-react"
import { motion } from "framer-motion"

export function GlossaryGameDemo() {
  const [gameKey, setGameKey] = useState(0)
  const [completionData, setCompletionData] = useState<{
    score: number
    total: number
    percentage: number
  } | null>(null)

  const handleGameComplete = (score: number, total: number) => {
    const percentage = Math.round((score / total) * 100)
    setCompletionData({ score, total, percentage })
  }

  const handleResetDemo = () => {
    setGameKey((prev) => prev + 1)
    setCompletionData(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Demo Header */}
        <div className="text-center mb-8">
          <motion.h1
            className="text-4xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Glossary Matching Game Demo
          </motion.h1>
          <motion.p
            className="text-lg text-gray-600 mb-6"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            Test your knowledge of mortgage terminology with this interactive matching game
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Button onClick={handleResetDemo} variant="outline" className="mb-6">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset Demo
            </Button>
          </motion.div>
        </div>

        {/* Completion Status */}
        {completionData && (
          <motion.div
            className="mb-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", duration: 0.5 }}
          >
            <Card className="p-6 bg-white shadow-lg">
              <div className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <Trophy className="w-8 h-8 text-yellow-500 mr-2" />
                  <h3 className="text-2xl font-bold text-gray-900">Game Complete!</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="text-3xl font-bold text-blue-600">{completionData.score}</div>
                    <div className="text-sm text-gray-600">Correct Answers</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gray-600">{completionData.total}</div>
                    <div className="text-sm text-gray-600">Total Questions</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">{completionData.percentage}%</div>
                    <div className="text-sm text-gray-600">Final Score</div>
                  </div>
                </div>
                {completionData.percentage === 100 && (
                  <motion.div
                    className="mt-4 text-green-600 font-medium"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.3 }}
                  >
                    🎉 Perfect Score! You're a mortgage terminology expert!
                  </motion.div>
                )}
              </div>
            </Card>
          </motion.div>
        )}

        {/* Game Component */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="bg-white shadow-xl">
            <GlossaryMatchingGame key={gameKey} onComplete={handleGameComplete} className="p-6" />
          </Card>
        </motion.div>

        {/* Instructions */}
        <motion.div className="mt-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">How to Play:</h3>
            <div className="grid md:grid-cols-2 gap-6 text-sm text-gray-600">
              <div>
                <h4 className="font-medium text-gray-800 mb-2">Desktop:</h4>
                <ul className="space-y-1">
                  <li>• Drag definitions from the right column</li>
                  <li>• Drop them onto matching terms on the left</li>
                  <li>• Click the info icon to view full definitions</li>
                  <li>• Use keyboard navigation with Tab and Enter</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-gray-800 mb-2">Mobile:</h4>
                <ul className="space-y-1">
                  <li>• Use dropdown menus to select definitions</li>
                  <li>• Tap the info icon for full definitions</li>
                  <li>• All interactions are touch-friendly</li>
                  <li>• Fully accessible with screen readers</li>
                </ul>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
