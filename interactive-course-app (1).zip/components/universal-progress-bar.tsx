"use client"

import type React from "react"

interface UniversalProgressBarProps {
  progress: number
  className?: string
  showPercentage?: boolean
  animated?: boolean
}

export function UniversalProgressBar({
  progress,
  className = "",
  showPercentage = true,
  animated = true,
}: UniversalProgressBarProps) {
  const clampedProgress = Math.min(Math.max(progress, 0), 100)

  return (
    <div
      className={`w-full ${className}`}
      role="progressbar"
      aria-valuenow={clampedProgress}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      {showPercentage && (
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Course Progress</span>
          <span className="text-sm font-bold">{clampedProgress}%</span>
        </div>
      )}
      <div className="progress">
        <div
          className={`progress-fill ${animated ? "animate-progress-fill" : ""}`}
          style={
            {
              width: `${clampedProgress}%`,
              "--target-width": `${clampedProgress}%`,
            } as React.CSSProperties
          }
        />
      </div>
    </div>
  )
}
