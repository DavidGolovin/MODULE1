"use client"

import React from "react"
import { UniversalProgressBar } from "./universal-progress-bar"
import { useEnhancedProgressTracking } from "../hooks/use-enhanced-progress-tracking"

interface AccessibleLessonLayoutProps {
  children: React.ReactNode
  lessonNumber: number
  lessonTitle: string
  showNavigation?: boolean
  className?: string
}

export function AccessibleLessonLayout({
  children,
  lessonNumber,
  lessonTitle,
  showNavigation = true,
  className = "",
}: AccessibleLessonLayoutProps) {
  const { currentLesson, progressPercentage, nextLesson, previousLesson, canGoNext, canGoPrevious, navigateToLesson } =
    useEnhancedProgressTracking()

  // Auto-navigate to current lesson if different
  React.useEffect(() => {
    if (currentLesson !== lessonNumber) {
      navigateToLesson(lessonNumber)
    }
  }, [lessonNumber, currentLesson, navigateToLesson])

  return (
    <div className={`theme-container min-h-screen ${className}`}>
      {/* Skip Link for Accessibility */}
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>

      {/* Progress Bar */}
      <div className="sticky top-0 z-10 theme-container border-b p-4">
        <UniversalProgressBar progress={progressPercentage} animated />
      </div>

      {/* Main Content */}
      <main id="main-content" className="flex-1 p-6" role="main">
        <div className="max-w-4xl mx-auto">
          {/* Lesson Header */}
          <header className="mb-8">
            <div className="responsive-stack mb-4">
              <h1 className="flex-1">
                Lesson {lessonNumber}: {lessonTitle}
              </h1>
              <div className="text-sm font-medium">Lesson {lessonNumber} of 15</div>
            </div>
          </header>

          {/* Lesson Content */}
          <div className="theme-container p-6 mb-8">{children}</div>

          {/* Navigation */}
          {showNavigation && (
            <nav className="responsive-stack justify-between" role="navigation" aria-label="Lesson navigation">
              <button
                onClick={previousLesson}
                disabled={!canGoPrevious}
                className="btn-secondary"
                aria-label="Go to previous lesson"
              >
                ← Previous Lesson
              </button>

              <div className="text-center">
                <span className="text-sm">Progress: {progressPercentage}% Complete</span>
              </div>

              <button onClick={nextLesson} disabled={!canGoNext} className="btn-primary" aria-label="Go to next lesson">
                Next Lesson →
              </button>
            </nav>
          )}
        </div>
      </main>
    </div>
  )
}
