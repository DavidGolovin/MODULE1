"use client"

import { useState } from "react"
import { ConfettiCelebration } from "./confetti-celebration"

export function CelebrationDemo() {
  const [showConfetti, setShowConfetti] = useState(false)
  const [intensity, setIntensity] = useState<"low" | "medium" | "high">("high")

  const triggerCelebration = () => {
    setShowConfetti(true)
  }

  const handleComplete = () => {
    setShowConfetti(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Confetti Celebration Demo</h1>
          <p className="text-lg text-gray-600 mb-8">
            Test the celebratory confetti effect with different intensity levels
          </p>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-semibold mb-6">Celebration Controls</h2>

          {/* Intensity Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">Confetti Intensity</label>
            <div className="flex gap-4">
              {(["low", "medium", "high"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setIntensity(level)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    intensity === level ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                  }`}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Trigger Button */}
          <button
            onClick={triggerCelebration}
            disabled={showConfetti}
            className="w-full bg-gradient-to-r from-green-500 to-blue-600 text-white font-bold py-4 px-8 rounded-xl hover:from-green-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 active:scale-95"
          >
            {showConfetti ? "Celebrating..." : "🎉 Trigger Celebration!"}
          </button>
        </div>

        {/* Feature Information */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-green-600">✅ Accessibility Features</h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Respects prefers-reduced-motion</li>
              <li>• aria-hidden for decorative content</li>
              <li>• Static emoji fallback for reduced motion</li>
              <li>• No keyboard traps or focus issues</li>
              <li>• Screen reader friendly</li>
            </ul>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold mb-4 text-blue-600">🎨 Visual Features</h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Multiple confetti shapes</li>
              <li>• Customizable colors and intensity</li>
              <li>• Physics-based animation</li>
              <li>• Smooth Framer Motion transitions</li>
              <li>• Full-screen overlay effect</li>
            </ul>
          </div>
        </div>

        {/* Usage Examples */}
        <div className="bg-white rounded-xl shadow-lg p-8 mt-8">
          <h3 className="text-2xl font-semibold mb-6">Usage Examples</h3>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
              <div className="text-3xl mb-2">🏆</div>
              <h4 className="font-semibold mb-2">Course Completion</h4>
              <p className="text-sm text-gray-600">Celebrate when students finish the entire course</p>
            </div>

            <div className="text-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
              <div className="text-3xl mb-2">✅</div>
              <h4 className="font-semibold mb-2">Quiz Success</h4>
              <p className="text-sm text-gray-600">Reward correct answers and perfect scores</p>
            </div>

            <div className="text-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
              <div className="text-3xl mb-2">🎯</div>
              <h4 className="font-semibold mb-2">Milestone Reached</h4>
              <p className="text-sm text-gray-600">Mark important learning achievements</p>
            </div>
          </div>
        </div>

        {/* Reduced Motion Notice */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mt-8">
          <div className="flex items-start gap-3">
            <div className="text-yellow-600 text-xl">⚠️</div>
            <div>
              <h4 className="font-semibold text-yellow-800 mb-2">Accessibility Note</h4>
              <p className="text-yellow-700 text-sm">
                If you have "Reduce motion" enabled in your system preferences, you'll see a static celebration instead
                of animated confetti. This ensures the experience is comfortable for users with motion sensitivity.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Confetti Effect */}
      <ConfettiCelebration isVisible={showConfetti} onComplete={handleComplete} intensity={intensity} duration={3000} />
    </div>
  )
}
