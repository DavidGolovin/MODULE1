"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { PageContainer } from "./page-container"
import { CheckCircle, Trophy, BookOpen, Rocket, Users, TrendingUp } from "lucide-react"

export function Page15_Conclusion() {
  const [animateStats, setAnimateStats] = useState(false)
  const [animateNextSteps, setAnimateNextSteps] = useState(false)

  useEffect(() => {
    const timer1 = setTimeout(() => setAnimateStats(true), 500)
    const timer2 = setTimeout(() => setAnimateNextSteps(true), 1000)

    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
    }
  }, [])

  const courseStats = [
    {
      number: "15",
      label: "Interactive Lessons",
      sublabel: "Completed",
      icon: BookOpen,
      borderColor: "border-roots-primary-accent",
      numberColor: "text-roots-primary-accent",
    },
    {
      number: "50+",
      label: "Key Concepts",
      sublabel: "Mastered",
      icon: Trophy,
      borderColor: "border-roots-icon-color",
      numberColor: "text-roots-icon-color",
    },
    {
      number: "100%",
      label: "Course Progress",
      sublabel: "Achieved",
      icon: CheckCircle,
      borderColor: "border-roots-text",
      numberColor: "text-roots-text",
    },
  ]

  const nextSteps = [
    {
      title: "Start Identifying Opportunities",
      description: "Look for properties with assumable loans in your market area",
    },
    {
      title: "Build Your Network",
      description: "Connect with lenders who handle loan assumptions regularly",
    },
    {
      title: "Create Marketing Materials",
      description: "Develop flyers and presentations highlighting assumable loan benefits",
    },
    {
      title: "Educate Your Clients",
      description: "Share knowledge about assumable mortgages with buyers and sellers",
    },
    {
      title: "Track Market Trends",
      description: "Monitor interest rate changes to identify the best opportunities",
    },
    {
      title: "Join Professional Groups",
      description: "Connect with other agents specializing in assumable mortgages",
    },
  ]

  return (
    <PageContainer>
      <div className="space-y-12">
        {/* Header Section */}
        <div className="text-center space-y-6 animate-fade-in-up">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold text-roots-text">
              <span className="text-roots-icon-color">🎉</span> Congratulations!{" "}
              <span className="text-roots-primary-accent">🎓</span>
            </h1>
            <p className="text-xl text-roots-dark-gray max-w-3xl mx-auto leading-relaxed">
              You've successfully completed the comprehensive course on assumable mortgages. You now have the knowledge
              and tools to help your clients save thousands of dollars and close deals faster in today's challenging
              market.
            </p>
          </div>
        </div>

        {/* Course Summary Stats */}
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-roots-text mb-2">Your Learning Journey</h2>
            <p className="text-roots-dark-gray">Here's what you've accomplished in this course</p>
          </div>

          <div
            className={`grid grid-cols-1 md:grid-cols-3 gap-6 transition-all duration-1000 ${
              animateStats ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            {courseStats.map((stat, index) => {
              const IconComponent = stat.icon
              return (
                <Card
                  key={stat.label}
                  className={`card-enhanced ${stat.borderColor} p-6 text-center hover:shadow-lg transition-all duration-300 hover:scale-[1.02]`}
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div className="space-y-4">
                    <div className="flex justify-center">
                      <div className={`p-3 rounded-full bg-roots-container-bg border ${stat.borderColor}`}>
                        <IconComponent className={`h-8 w-8 ${stat.numberColor}`} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className={`text-4xl font-bold ${stat.numberColor}`}>{stat.number}</div>
                      <div className="space-y-1">
                        <div className="text-lg font-semibold text-roots-text">{stat.label}</div>
                        <div className="text-sm text-roots-dark-gray">{stat.sublabel}</div>
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Key Achievements */}
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: "800ms" }}>
          <div className="text-center">
            <h2 className="text-3xl font-bold text-roots-text mb-2">
              <span className="text-roots-primary-accent">✅</span> What You've Mastered
            </h2>
            <p className="text-roots-dark-gray">
              You're now equipped with expert-level knowledge in assumable mortgages
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Market Analysis",
                description: "Identify profitable assumable loan opportunities",
                icon: TrendingUp,
              },
              {
                title: "Client Education",
                description: "Explain complex concepts in simple terms",
                icon: Users,
              },
              {
                title: "Financial Calculations",
                description: "Calculate savings and payment differences",
                icon: Trophy,
              },
              {
                title: "Risk Assessment",
                description: "Evaluate potential challenges and solutions",
                icon: CheckCircle,
              },
              {
                title: "Process Management",
                description: "Navigate the assumption process efficiently",
                icon: Rocket,
              },
              {
                title: "Professional Network",
                description: "Build relationships with key stakeholders",
                icon: Users,
              },
            ].map((achievement, index) => {
              const IconComponent = achievement.icon
              return (
                <Card
                  key={achievement.title}
                  className="card-enhanced border-roots-border-line p-4 hover:border-roots-primary-accent hover:shadow-md transition-all duration-300"
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <IconComponent className="h-6 w-6 text-roots-icon-color mt-1" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-semibold text-roots-text">{achievement.title}</h4>
                      <p className="text-sm text-roots-dark-gray">{achievement.description}</p>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Next Steps Section */}
        <div
          className={`transition-all duration-1000 ${
            animateNextSteps ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <Card className="card-enhanced relative overflow-hidden">
            {/* Gradient Border Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-roots-primary-accent to-roots-icon-color p-[2px] rounded-lg">
              <div className="bg-roots-page-bg rounded-lg h-full w-full p-8">
                <div className="space-y-6">
                  <div className="text-center space-y-4">
                    <h2 className="text-3xl font-bold text-roots-text">
                      <span className="text-roots-primary-accent">🚀</span> Ready to Apply Your Knowledge?
                    </h2>
                    <p className="text-lg text-roots-dark-gray max-w-2xl mx-auto">
                      Here are your next steps to start implementing assumable mortgage strategies in your real estate
                      practice and help your clients achieve their homeownership goals.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {nextSteps.map((step, index) => (
                      <div
                        key={step.title}
                        className="flex items-start space-x-4 p-4 rounded-lg bg-roots-container-bg border border-roots-border-line hover:border-roots-primary-accent transition-all duration-300"
                      >
                        <div className="flex-shrink-0 mt-1">
                          <div className="w-6 h-6 rounded-full bg-roots-primary-accent flex items-center justify-center">
                            <CheckCircle className="h-4 w-4 text-roots-text" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-semibold text-roots-text">{step.title}</h4>
                          <p className="text-sm text-roots-dark-gray">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="text-center pt-6 border-t border-roots-border-line">
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-roots-text">Your Success Starts Now</h3>
                      <p className="text-roots-dark-gray max-w-xl mx-auto">
                        With the knowledge you've gained, you're positioned to become a leader in assumable mortgage
                        transactions. Start applying these strategies today and watch your business grow!
                      </p>
                      <div className="flex justify-center space-x-2 text-2xl">
                        <span className="text-roots-primary-accent">🎉</span>
                        <span className="text-roots-icon-color">🎓</span>
                        <span className="text-roots-primary-accent">🚀</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  )
}

export default Page15_Conclusion
