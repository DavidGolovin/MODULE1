"use client"

import { memo, useState } from "react"
import { Card } from "@/components/ui/card"
import { EnhancedButton } from "@/components/enhanced-button"
import { CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react"

interface CompletionTestPanelProps {
  currentPage: number
  pageCompletions: Record<number, boolean>
  onPageCompletion: (pageNumber: number, completed: boolean) => void
}

export const CompletionTestPanel = memo<CompletionTestPanelProps>(
  ({ currentPage, pageCompletions, onPageCompletion }) => {
    const [isVisible, setIsVisible] = useState(false)

    const pageRequirements = {
      1: "Confirm name and details",
      2: "Spend 30+ seconds reading content",
      3: "Explore key years (2020, 2021, 2023, 2024)",
      4: "Complete a savings calculation",
      5: "Read through win-win scenarios",
      6: "Review eligible loan types",
      7: "Answer all quiz questions correctly",
      8: "Click through all 6 process steps",
      9: "Explore down payment gap scenarios",
      10: "Complete risk assessment tool",
      11: "Check all high-priority checklist items",
      12: "Complete all 4 role-playing scenarios",
      13: "Complete interactive case study",
      14: "Match all glossary terms",
      15: "Review conclusion (always completed)",
    }

    const getCompletionStatus = (pageNum: number) => {
      const isCompleted = pageCompletions[pageNum] || false
      const isCurrent = pageNum === currentPage

      if (isCompleted) {
        return {
          icon: <CheckCircle className="w-4 h-4 text-green-500" />,
          status: "Completed",
          color: "text-green-600",
        }
      } else if (isCurrent) {
        return { icon: <Clock className="w-4 h-4 text-orange-500" />, status: "In Progress", color: "text-orange-600" }
      } else if (pageNum < currentPage) {
        return { icon: <XCircle className="w-4 h-4 text-red-500" />, status: "Incomplete", color: "text-red-600" }
      } else {
        return {
          icon: <AlertTriangle className="w-4 h-4 text-gray-400" />,
          status: "Not Started",
          color: "text-gray-500",
        }
      }
    }

    const toggleCompletion = (pageNum: number) => {
      const currentStatus = pageCompletions[pageNum] || false
      onPageCompletion(pageNum, !currentStatus)
    }

    const completedCount = Object.values(pageCompletions).filter(Boolean).length
    const totalPages = Object.keys(pageRequirements).length

    if (!isVisible) {
      return (
        <div className="fixed bottom-4 right-4 z-50">
          <EnhancedButton
            onClick={() => setIsVisible(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
          >
            🧪 Test Panel
          </EnhancedButton>
        </div>
      )
    }

    return (
      <div className="fixed bottom-4 right-4 z-50 w-96 max-h-96 overflow-y-auto">
        <Card className="p-4 bg-white shadow-xl border-2 border-blue-500">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-800">🧪 Completion Test Panel</h3>
            <EnhancedButton onClick={() => setIsVisible(false)} variant="secondary" className="text-xs px-2 py-1">
              ✕
            </EnhancedButton>
          </div>

          {/* Overall Progress */}
          <div className="mb-4 p-3 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm font-bold">
                {completedCount}/{totalPages}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(completedCount / totalPages) * 100}%` }}
              />
            </div>
          </div>

          {/* Current Page Status */}
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm font-medium">Current Page {currentPage}:</span>
              {getCompletionStatus(currentPage).icon}
              <span className={`text-sm ${getCompletionStatus(currentPage).color}`}>
                {getCompletionStatus(currentPage).status}
              </span>
            </div>
            <p className="text-xs text-gray-600">{pageRequirements[currentPage as keyof typeof pageRequirements]}</p>
          </div>

          {/* Page List */}
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {Object.entries(pageRequirements).map(([pageNum, requirement]) => {
              const num = Number.parseInt(pageNum)
              const status = getCompletionStatus(num)
              const isCurrentPage = num === currentPage

              return (
                <div
                  key={pageNum}
                  className={`p-2 rounded border text-xs ${
                    isCurrentPage ? "bg-blue-100 border-blue-300" : "bg-gray-50 border-gray-200"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Page {pageNum}</span>
                      {status.icon}
                      <span className={status.color}>{status.status}</span>
                    </div>
                    <EnhancedButton
                      onClick={() => toggleCompletion(num)}
                      className="text-xs px-2 py-1"
                      variant={pageCompletions[num] ? "danger" : "success"}
                    >
                      {pageCompletions[num] ? "Reset" : "Complete"}
                    </EnhancedButton>
                  </div>
                  <p className="text-gray-600">{requirement}</p>
                </div>
              )
            })}
          </div>

          {/* Test Actions */}
          <div className="mt-4 pt-3 border-t border-gray-200">
            <div className="grid grid-cols-2 gap-2">
              <EnhancedButton
                onClick={() => {
                  Object.keys(pageRequirements).forEach((pageNum) => {
                    onPageCompletion(Number.parseInt(pageNum), true)
                  })
                }}
                className="text-xs"
                variant="success"
              >
                Complete All
              </EnhancedButton>
              <EnhancedButton
                onClick={() => {
                  Object.keys(pageRequirements).forEach((pageNum) => {
                    onPageCompletion(Number.parseInt(pageNum), false)
                  })
                }}
                className="text-xs"
                variant="danger"
              >
                Reset All
              </EnhancedButton>
            </div>
          </div>

          {/* Test Results */}
          <div className="mt-3 p-2 bg-gray-100 rounded text-xs">
            <div className="font-medium mb-1">Test Results:</div>
            <div className="space-y-1">
              <div>✅ Completed: {Object.values(pageCompletions).filter(Boolean).length}</div>
              <div>❌ Incomplete: {Object.values(pageCompletions).filter((v) => !v).length}</div>
              <div>🔒 Navigation: {pageCompletions[currentPage] ? "Unlocked" : "Locked"}</div>
            </div>
          </div>
        </Card>
      </div>
    )
  },
)

CompletionTestPanel.displayName = "CompletionTestPanel"
