"use client"

import type React from "react"

import { memo, useState, useCallback, useMemo } from "react"
import { PageContainer } from "./page-container"
import { EnhancedCard } from "./enhanced-card"
import { EnhancedButton } from "./enhanced-button"
import { EnhancedInput } from "./enhanced-input"
import { InfoModal } from "./info-modal"
import { SuccessBurst } from "./success-burst"
import { ParticleSystem } from "./particle-system"
import { FormInput, Send, CheckSquare, Radio, List, Calendar } from "lucide-react"

export const Page4_HtmlForms = memo(() => {
  const [showModal, setShowModal] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [showParticles, setShowParticles] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    newsletter: false,
    experience: "",
    rating: "",
  })
  const [completedInputs, setCompletedInputs] = useState<Set<string>>(new Set())

  const inputTypes = useMemo(
    () => [
      {
        id: "text",
        type: "text",
        label: "Text Input",
        description: "Single-line text input for names, titles, etc.",
        example: '<input type="text" name="username" placeholder="Enter username">',
        icon: <FormInput className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "email",
        type: "email",
        label: "Email Input",
        description: "Validates email format and shows appropriate keyboard",
        example: '<input type="email" name="email" placeholder="user@example.com">',
        icon: <Send className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "password",
        type: "password",
        label: "Password Input",
        description: "Hides input text for security",
        example: '<input type="password" name="password" placeholder="Password">',
        icon: <FormInput className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "checkbox",
        type: "checkbox",
        label: "Checkbox",
        description: "Multiple selections or yes/no options",
        example: '<input type="checkbox" name="subscribe" id="subscribe">',
        icon: <CheckSquare className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "radio",
        type: "radio",
        label: "Radio Button",
        description: "Single selection from multiple options",
        example: '<input type="radio" name="experience" value="beginner" id="beginner">',
        icon: <Radio className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "select",
        type: "select",
        label: "Select Dropdown",
        description: "Dropdown menu with predefined options",
        example: '<select name="country"><option value="us">United States</option></select>',
        icon: <List className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "textarea",
        type: "textarea",
        label: "Text Area",
        description: "Multi-line text input for longer content",
        example: '<textarea name="message" rows="4" placeholder="Your message"></textarea>',
        icon: <FormInput className="w-5 h-5 text-roots-icon-color" />,
      },
      {
        id: "date",
        type: "date",
        label: "Date Input",
        description: "Date picker for selecting dates",
        example: '<input type="date" name="birthdate">',
        icon: <Calendar className="w-5 h-5 text-roots-icon-color" />,
      },
    ],
    [],
  )

  const sampleForm = useMemo(
    () => `<form action="/submit" method="POST">
  <div>
    <label for="name">Full Name:</label>
    <input type="text" id="name" name="name" required>
  </div>
  
  <div>
    <label for="email">Email Address:</label>
    <input type="email" id="email" name="email" required>
  </div>
  
  <div>
    <label for="experience">Experience Level:</label>
    <select id="experience" name="experience">
      <option value="">Choose...</option>
      <option value="beginner">Beginner</option>
      <option value="intermediate">Intermediate</option>
      <option value="advanced">Advanced</option>
    </select>
  </div>
  
  <div>
    <input type="checkbox" id="newsletter" name="newsletter">
    <label for="newsletter">Subscribe to newsletter</label>
  </div>
  
  <div>
    <label for="message">Message:</label>
    <textarea id="message" name="message" rows="4"></textarea>
  </div>
  
  <button type="submit">Submit Form</button>
</form>`,
    [],
  )

  const handleOpenModal = useCallback(() => {
    setShowModal(true)
  }, [])

  const handleCloseModal = useCallback(() => {
    setShowModal(false)
  }, [])

  const handleInputChange = useCallback((field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setCompletedInputs((prev) => new Set([...prev, field]))
  }, [])

  const handleFormSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault()
    setShowSuccess(true)
    setShowParticles(true)
    setTimeout(() => setShowParticles(false), 3000)
  }, [])

  const handleInputTypeSelect = useCallback((inputId: string) => {
    setCompletedInputs((prev) => new Set([...prev, inputId]))
    setShowSuccess(true)
  }, [])

  const isCompleted = useCallback(
    (inputId: string) => {
      return completedInputs.has(inputId)
    },
    [completedInputs],
  )

  return (
    <PageContainer
      title="HTML Forms: Collecting User Input"
      subtitle="Learn how to create interactive forms for user data collection"
    >
      <ParticleSystem active={showParticles} />

      <div className="space-y-8">
        {/* Introduction */}
        <EnhancedCard className="animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-roots-primary-accent rounded-xl">
              <FormInput className="w-8 h-8 text-roots-text" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-roots-text mb-3 font-inter">Why Forms Are Essential</h2>
              <p className="text-roots-dark-gray mb-4 font-inter leading-relaxed">
                Forms are the primary way users interact with websites. They allow you to collect information, process
                user input, and create interactive experiences. From simple contact forms to complex registration
                systems, forms are everywhere on the web.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">User Input</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Collect data from users</p>
                </div>
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">Interaction</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Enable user engagement</p>
                </div>
                <div className="bg-roots-light-gray p-3 rounded-lg text-center">
                  <h4 className="font-bold text-roots-text font-inter text-sm">Validation</h4>
                  <p className="text-xs text-roots-dark-gray font-inter">Ensure data quality</p>
                </div>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Input Types */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {inputTypes.map((input, index) => (
            <EnhancedCard
              key={input.id}
              className={`cursor-pointer transition-all duration-300 animate-fade-in-up ${
                isCompleted(input.id) ? "bg-green-50 border-green-200" : ""
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => handleInputTypeSelect(input.id)}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {input.icon}
                  <h4 className="font-bold text-roots-text font-inter">{input.label}</h4>
                </div>
                {isCompleted(input.id) && <CheckSquare className="w-5 h-5 text-green-500" />}
              </div>
              <p className="text-sm text-roots-dark-gray font-inter mb-3">{input.description}</p>
              <code className="block bg-roots-container-bg p-2 rounded text-xs font-mono text-roots-text overflow-x-auto">
                {input.example}
              </code>
            </EnhancedCard>
          ))}
        </div>

        {/* Interactive Form Example */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">Try It Yourself: Contact Form</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold text-roots-text mb-4 font-inter">Interactive Form</h4>
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <EnhancedInput
                  label="Full Name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter your full name"
                  required
                />

                <EnhancedInput
                  label="Email Address"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="your.email@example.com"
                  required
                />

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-roots-text font-inter">Experience Level</label>
                  <select
                    value={formData.experience}
                    onChange={(e) => handleInputChange("experience", e.target.value)}
                    className="w-full px-3 py-2 border-2 border-roots-medium-gray rounded-lg bg-roots-page-bg text-roots-text font-inter focus:border-roots-icon-color focus:outline-none"
                  >
                    <option value="">Choose your level...</option>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-roots-text font-inter">Message</label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => handleInputChange("message", e.target.value)}
                    placeholder="Tell us about your goals..."
                    rows={4}
                    className="w-full px-3 py-2 border-2 border-roots-medium-gray rounded-lg bg-roots-page-bg text-roots-text font-inter focus:border-roots-icon-color focus:outline-none resize-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newsletter"
                    checked={formData.newsletter}
                    onChange={(e) => handleInputChange("newsletter", e.target.checked)}
                    className="w-4 h-4 text-roots-primary-accent border-roots-medium-gray rounded focus:ring-roots-icon-color"
                  />
                  <label htmlFor="newsletter" className="text-sm text-roots-text font-inter">
                    Subscribe to our newsletter for updates
                  </label>
                </div>

                <EnhancedButton type="submit" size="lg" className="w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Submit Form
                </EnhancedButton>
              </form>
            </div>

            <div>
              <h4 className="font-bold text-roots-text mb-4 font-inter">HTML Code</h4>
              <div className="bg-roots-container-bg p-4 rounded-lg max-h-96 overflow-y-auto">
                <pre className="text-xs font-mono text-roots-text whitespace-pre-wrap">{sampleForm}</pre>
              </div>
              <div className="mt-4">
                <EnhancedButton variant="secondary" size="sm" onClick={() => navigator.clipboard.writeText(sampleForm)}>
                  Copy HTML Code
                </EnhancedButton>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Form Validation */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "1s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">Form Validation</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">HTML5 Validation Attributes</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">required</code>
                  <span className="text-roots-dark-gray font-inter">Field must be filled out</span>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">minlength</code>
                  <span className="text-roots-dark-gray font-inter">Minimum character length</span>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">maxlength</code>
                  <span className="text-roots-dark-gray font-inter">Maximum character length</span>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">pattern</code>
                  <span className="text-roots-dark-gray font-inter">Regular expression pattern</span>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">min/max</code>
                  <span className="text-roots-dark-gray font-inter">Numeric range limits</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">Best Practices</h4>
              <ul className="space-y-2 text-sm text-roots-dark-gray font-inter">
                <li>• Always include labels for accessibility</li>
                <li>• Use appropriate input types for better UX</li>
                <li>• Provide clear error messages</li>
                <li>• Group related fields with fieldset</li>
                <li>• Use placeholder text as hints, not labels</li>
                <li>• Test forms on mobile devices</li>
              </ul>
            </div>
          </div>
        </EnhancedCard>

        {/* Form Accessibility */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "1.2s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">Form Accessibility</h3>
          <div className="card-container p-4">
            <h4 className="font-bold text-roots-text mb-3 font-inter">Essential Accessibility Features</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Label every form control</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Use fieldset for grouped controls</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Provide clear instructions</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Indicate required fields</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Use ARIA attributes when needed</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-roots-text" />
                  <span className="text-roots-text font-inter">Ensure keyboard navigation works</span>
                </div>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <EnhancedButton size="lg" onClick={handleOpenModal}>
            View Form Examples
          </EnhancedButton>
          <EnhancedButton size="lg" variant="success">
            Practice Form Building
          </EnhancedButton>
        </div>
      </div>

      {/* Form Examples Modal */}
      <InfoModal isOpen={showModal} onClose={handleCloseModal} title="Common Form Examples">
        <div className="space-y-6">
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Contact Form</h4>
            <code className="block bg-roots-container-bg p-3 rounded text-xs font-mono text-roots-text overflow-x-auto">
              {`<form>
  <input type="text" name="name" placeholder="Name" required>
  <input type="email" name="email" placeholder="Email" required>
  <textarea name="message" placeholder="Message"></textarea>
  <button type="submit">Send</button>
</form>`}
            </code>
          </div>
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Registration Form</h4>
            <code className="block bg-roots-container-bg p-3 rounded text-xs font-mono text-roots-text overflow-x-auto">
              {`<form>
  <input type="text" name="username" placeholder="Username" required>
  <input type="email" name="email" placeholder="Email" required>
  <input type="password" name="password" placeholder="Password" required>
  <input type="date" name="birthdate">
  <select name="country">
    <option>Select Country</option>
  </select>
  <button type="submit">Register</button>
</form>`}
            </code>
          </div>
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Survey Form</h4>
            <code className="block bg-roots-container-bg p-3 rounded text-xs font-mono text-roots-text overflow-x-auto">
              {`<form>
  <fieldset>
    <legend>Experience Level</legend>
    <input type="radio" name="level" value="beginner" id="beginner">
    <label for="beginner">Beginner</label>
    <input type="radio" name="level" value="advanced" id="advanced">
    <label for="advanced">Advanced</label>
  </fieldset>
  <input type="range" name="satisfaction" min="1" max="10">
  <button type="submit">Submit Survey</button>
</form>`}
            </code>
          </div>
        </div>
      </InfoModal>

      <SuccessBurst
        show={showSuccess}
        message="Excellent! You're mastering HTML forms!"
        onComplete={() => setShowSuccess(false)}
      />
    </PageContainer>
  )
})

Page4_HtmlForms.displayName = "Page4_HtmlForms"
