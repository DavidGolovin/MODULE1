"use client"

import type React from "react"
import { memo, useCallback } from "react"
import { Sparkles } from "lucide-react"

interface CelebrationTriggerProps {
  onTrigger?: () => void
  children?: React.ReactNode
  className?: string
}

export const CelebrationTrigger = memo<CelebrationTriggerProps>(({ onTrigger, children, className = "" }) => {
  const handleClick = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault()
      e.stopPropagation()

      try {
        if (onTrigger && typeof onTrigger === "function") {
          onTrigger()
        } else {
          console.warn("CelebrationTrigger: onTrigger prop is not a valid function", { onTrigger })
        }
      } catch (error) {
        console.error("CelebrationTrigger: Error calling onTrigger", error)
      }
    },
    [onTrigger],
  )

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`
        inline-flex items-center gap-2 px-4 py-2 bg-roots-primary-accent text-roots-text
        rounded-lg font-medium font-inter transition-all duration-300
        hover:bg-opacity-90 hover:scale-105 active:scale-95
        disabled:opacity-50 disabled:cursor-not-allowed
        ${className}
      `}
    >
      <Sparkles className="w-4 h-4" />
      {children || "Celebrate!"}
    </button>
  )
})

CelebrationTrigger.displayName = "CelebrationTrigger"
