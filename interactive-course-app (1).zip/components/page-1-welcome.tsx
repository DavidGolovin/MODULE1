"use client"

import type React from "react"
import { memo, useState, useCallback, useMemo } from "react"
import { PageContainer } from "./page-container"
import { EnhancedInput } from "./enhanced-input"
import { EnhancedButton } from "./enhanced-button"
import { User, Loader2, CheckCircle } from "lucide-react"
import { Box, Typography, Grid, Card, CardContent, Container } from "@mui/material"
import { styled } from "@mui/material/styles"
import { useTheme } from "@mui/material/styles"

interface Page1_WelcomeProps {
  onUserNameConfirmed: (confirmed: boolean, name: string) => void
  onAdvanceToNextPage: () => void
  userName: string
}

interface FormData {
  firstName: string
  lastName: string
  licenseNumber: string
}

interface FormErrors {
  firstName?: string
  lastName?: string
  licenseNumber?: string
}

const Item = styled(Card)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
  boxShadow: "0px 2px 1px -1px rgb(0 0 0 / 20%), 0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%)",
  borderRadius: "4px",
}))

export const Page1_Welcome = memo<Page1_WelcomeProps>(({ onUserNameConfirmed, onAdvanceToNextPage, userName }) => {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    licenseNumber: "",
  })
  const [errors, setErrors] = useState<FormErrors>({})
  const [isLoading, setIsLoading] = useState(false)
  const [isConfirmed, setIsConfirmed] = useState(!!userName)
  const theme = useTheme()

  // Validation regex for names (letters, spaces, hyphens, apostrophes)
  const nameRegex = useMemo(() => /^[a-zA-Z\s\-']+$/, [])

  const validateField = useCallback(
    (field: keyof FormData, value: string): string | undefined => {
      switch (field) {
        case "firstName":
        case "lastName":
          if (value.length < 2) {
            return `${field === "firstName" ? "First" : "Last"} name must be at least 2 characters`
          }
          if (!nameRegex.test(value)) {
            return "Name can only contain letters, spaces, hyphens, and apostrophes"
          }
          return undefined
        case "licenseNumber":
          if (!value.trim()) {
            return "License number is required"
          }
          if (value.trim().length < 3) {
            return "License number must be at least 3 characters"
          }
          return undefined
        default:
          return undefined
      }
    },
    [nameRegex],
  )

  const validateForm = useCallback((): boolean => {
    const newErrors: FormErrors = {}
    let isValid = true

    Object.keys(formData).forEach((key) => {
      const field = key as keyof FormData
      const error = validateField(field, formData[field])
      if (error) {
        newErrors[field] = error
        isValid = false
      }
    })

    setErrors(newErrors)
    return isValid
  }, [formData, validateField])

  const handleInputChange = useCallback(
    (field: keyof FormData, value: string) => {
      setFormData((prev) => ({ ...prev, [field]: value }))

      // Real-time validation
      const error = validateField(field, value)
      setErrors((prev) => ({
        ...prev,
        [field]: error,
      }))
    },
    [validateField],
  )

  const simulateApiCall = useCallback(async (): Promise<boolean> => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    // Always return success for demo
    return true
  }, [])

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()

      if (!validateForm()) {
        return
      }

      setIsLoading(true)

      try {
        const success = await simulateApiCall()

        if (success) {
          const fullName = `${formData.firstName} ${formData.lastName}`
          setIsConfirmed(true)
          onUserNameConfirmed(true, fullName)
        } else {
          setErrors({
            licenseNumber: "Unable to verify license number. Please try again.",
          })
        }
      } catch (error) {
        setErrors({
          licenseNumber: "An error occurred. Please try again.",
        })
      } finally {
        setIsLoading(false)
      }
    },
    [formData, validateForm, simulateApiCall, onUserNameConfirmed],
  )

  const handleChangeName = useCallback(() => {
    setIsConfirmed(false)
    setFormData({
      firstName: "",
      lastName: "",
      licenseNumber: "",
    })
    setErrors({})
    onUserNameConfirmed(false, "")
  }, [onUserNameConfirmed])

  const handleContinue = useCallback(() => {
    onAdvanceToNextPage()
  }, [onAdvanceToNextPage])

  const isFormValid = useMemo(() => {
    return (
      formData.firstName.trim().length >= 2 &&
      formData.lastName.trim().length >= 2 &&
      formData.licenseNumber.trim().length >= 3 &&
      Object.values(errors).every((error) => !error)
    )
  }, [formData, errors])

  if (isConfirmed && userName) {
    return (
      <PageContainer>
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Confirmed Welcome Section */}
          <div className="text-center animate-fade-in-up">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="p-4 bg-roots-primary-accent rounded-full">
                <User className="w-8 h-8 text-roots-text" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-roots-text font-inter">
                Welcome, {userName}! <span className="text-roots-icon-color">👋</span>
              </h1>
            </div>
            <p className="text-lg text-roots-dark-gray font-inter mb-8">
              Great! Your information has been confirmed. You're all set to begin your learning journey with Roots.
            </p>
          </div>

          {/* Action Buttons */}
          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up"
            style={{ animationDelay: "0.2s" }}
          >
            <EnhancedButton variant="secondary" onClick={handleChangeName}>
              Change Name
            </EnhancedButton>
            <EnhancedButton size="lg" onClick={handleContinue}>
              Continue to Course
            </EnhancedButton>
          </div>

          {/* Success Indicator */}
          <div
            className="flex items-center justify-center gap-2 text-green-600 animate-fade-in-up"
            style={{ animationDelay: "0.4s" }}
          >
            <CheckCircle className="w-5 h-5" />
            <span className="font-inter font-medium">Profile Confirmed</span>
          </div>
        </div>

        {/* Available Lessons Section */}
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
          <Box
            sx={{
              bgcolor: "background.paper",
              borderRadius: "4px",
              padding: 3,
              mb: 3,
            }}
          >
            <Typography
              variant="h4"
              component="h1"
              gutterBottom
              sx={{
                fontFamily: "Inter, sans-serif",
                fontWeight: 600,
                color: theme.palette.text.primary,
              }}
            >
              Welcome to the Learning Platform!
            </Typography>
            <Typography
              variant="body1"
              sx={{
                fontFamily: "Inter, sans-serif",
                color: theme.palette.text.secondary,
              }}
            >
              Explore our interactive lessons and expand your knowledge. Get started by browsing the available courses
              below.
            </Typography>
          </Box>

          <Typography
            variant="h6"
            component="h2"
            gutterBottom
            sx={{
              fontFamily: "Inter, sans-serif",
              fontWeight: 600,
              color: theme.palette.text.primary,
              mt: 4,
              mb: 2,
            }}
          >
            Available Lessons
          </Typography>

          <Grid container spacing={3}>
            {/* Example Lesson Cards - Replace with dynamic data */}
            <Grid item xs={12} sm={6} md={4}>
              <Item>
                <CardContent>
                  <Typography
                    variant="h6"
                    component="h3"
                    sx={{ fontFamily: "Inter, sans-serif", fontWeight: 500, color: theme.palette.text.primary }}
                  >
                    Lesson 1: Introduction to React
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontFamily: "Inter, sans-serif", color: theme.palette.text.secondary }}
                  >
                    Learn the basics of React and JSX.
                  </Typography>
                </CardContent>
              </Item>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Item>
                <CardContent>
                  <Typography
                    variant="h6"
                    component="h3"
                    sx={{ fontFamily: "Inter, sans-serif", fontWeight: 500, color: theme.palette.text.primary }}
                  >
                    Lesson 2: State Management
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontFamily: "Inter, sans-serif", color: theme.palette.text.secondary }}
                  >
                    Explore different state management techniques.
                  </Typography>
                </CardContent>
              </Item>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Item>
                <CardContent>
                  <Typography
                    variant="h6"
                    component="h3"
                    sx={{ fontFamily: "Inter, sans-serif", fontWeight: 500, color: theme.palette.text.primary }}
                  >
                    Lesson 3: Working with APIs
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontFamily: "Inter, sans-serif", color: theme.palette.text.secondary }}
                  >
                    Fetch and display data from external APIs.
                  </Typography>
                </CardContent>
              </Item>
            </Grid>
            {/* Add more lesson cards here */}
          </Grid>
        </Container>
      </PageContainer>
    )
  }

  return (
    <PageContainer>
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Welcome Header */}
        <div className="text-center animate-fade-in-up">
          <h1 className="text-3xl md:text-4xl font-bold text-roots-text font-inter mb-4">
            Welcome to Roots! <span className="text-roots-icon-color">👋</span>
          </h1>
          <p className="text-lg text-roots-dark-gray font-inter mb-2">
            We're excited to have you join our learning community!
          </p>
          <p className="text-roots-dark-gray font-inter">
            Please provide your information below to get started with your personalized learning experience.
          </p>
        </div>

        {/* Registration Form */}
        <div
          className="bg-roots-container-bg border border-roots-border-line rounded-xl p-8 animate-fade-in-up"
          style={{ animationDelay: "0.2s" }}
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* First Name */}
              <div className="relative">
                <EnhancedInput
                  label="First Name"
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  placeholder="Enter your first name"
                  error={errors.firstName}
                  className="pl-10"
                  required
                />
                <User className="absolute left-3 top-8 w-4 h-4 text-roots-icon-color" />
              </div>

              {/* Last Name */}
              <div className="relative">
                <EnhancedInput
                  label="Last Name"
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  placeholder="Enter your last name"
                  error={errors.lastName}
                  className="pl-10"
                  required
                />
                <User className="absolute left-3 top-8 w-4 h-4 text-roots-icon-color" />
              </div>
            </div>

            {/* License Number */}
            <div className="relative">
              <EnhancedInput
                label="License Number"
                type="text"
                value={formData.licenseNumber}
                onChange={(e) => handleInputChange("licenseNumber", e.target.value)}
                placeholder="Enter your license number"
                error={errors.licenseNumber}
                className="pl-10"
                required
              />
              <User className="absolute left-3 top-8 w-4 h-4 text-roots-icon-color" />
            </div>

            {/* Real-time Validation Feedback */}
            {formData.firstName && !errors.firstName && (
              <div className="flex items-center gap-2 text-green-600 text-sm font-inter">
                <CheckCircle className="w-4 h-4" />
                <span>First name looks good!</span>
              </div>
            )}

            {formData.lastName && !errors.lastName && (
              <div className="flex items-center gap-2 text-green-600 text-sm font-inter">
                <CheckCircle className="w-4 h-4" />
                <span>Last name looks good!</span>
              </div>
            )}

            {formData.licenseNumber && !errors.licenseNumber && (
              <div className="flex items-center gap-2 text-green-600 text-sm font-inter">
                <CheckCircle className="w-4 h-4" />
                <span>License number provided!</span>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-4">
              <EnhancedButton type="submit" size="lg" className="w-full" disabled={!isFormValid || isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Verifying Information...
                  </>
                ) : (
                  "Start Course"
                )}
              </EnhancedButton>
            </div>
          </form>
        </div>

        {/* Additional Information */}
        <div
          className="text-center text-sm text-roots-dark-gray font-inter animate-fade-in-up"
          style={{ animationDelay: "0.4s" }}
        >
          <p>Your information is secure and will only be used to personalize your learning experience.</p>
        </div>
      </div>
    </PageContainer>
  )
})

Page1_Welcome.displayName = "Page1_Welcome"
