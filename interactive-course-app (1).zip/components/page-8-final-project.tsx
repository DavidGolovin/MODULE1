"use client"

import { useState, useCallback } from "react"
import { GlossaryMatchingGame } from "./glossary-matching-game"

interface Page8FinalProjectProps {
  onNextPage?: () => void
  onPrevPage?: () => void
  onPageCompletion?: (completed: boolean) => void
  isCompleted?: boolean
}

export function Page8FinalProject({
  onNextPage,
  onPrevPage,
  onPageCompletion,
  isCompleted = false,
}: Page8FinalProjectProps) {
  const [gameCompleted, setGameCompleted] = useState(isCompleted)

  const handleGameComplete = useCallback(
    (score: number, totalQuestions: number) => {
      const passed = score >= Math.ceil(totalQuestions * 0.7) // 70% to pass
      setGameCompleted(passed)
      onPageCompletion?.(passed)
    },
    [onPageCompletion],
  )

  return (
    <div className="min-h-screen bg-white font-inter">
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <header className="text-center mb-12 animate-fade-in-up">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4 font-inter">🎉 Congratulations!</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed font-inter">
            You've successfully completed the HTML fundamentals course. Test your knowledge with this final challenge!
          </p>
        </header>

        {/* Glossary Matching Game */}
        <section className="mb-12 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          <div className="global-container p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-primary mb-4 font-inter">Final Challenge: HTML Terms Matching</h2>
              <p className="text-gray-600 font-inter">
                Match the HTML terms with their correct definitions to complete the course.
              </p>
            </div>

            <GlossaryMatchingGame onComplete={handleGameComplete} className="w-full" />
          </div>
        </section>

        {/* Completion Status */}
        {gameCompleted && (
          <section className="text-center mb-12 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <div className="global-container p-8">
              <div className="space-y-6">
                <div className="text-6xl mb-4">🎓</div>
                <h2 className="text-3xl font-bold text-primary mb-4 font-inter">Course Complete!</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto font-inter">
                  You've mastered the fundamentals of HTML and are ready to start building amazing web pages. Keep
                  practicing and exploring more advanced topics!
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                  <div className="global-container p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2 font-inter">8</div>
                    <div className="text-sm text-gray-600 font-inter">Lessons Completed</div>
                  </div>
                  <div className="global-container p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2 font-inter">100%</div>
                    <div className="text-sm text-gray-600 font-inter">Course Progress</div>
                  </div>
                  <div className="global-container p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2 font-inter">✓</div>
                    <div className="text-sm text-gray-600 font-inter">Certificate Earned</div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Navigation */}
        <nav className="flex justify-between items-center" role="navigation" aria-label="Lesson navigation">
          <button
            onClick={onPrevPage}
            className="btn-secondary px-6 py-3 font-inter"
            aria-label="Go to previous lesson"
          >
            ← Previous Lesson
          </button>

          {gameCompleted && (
            <div className="text-center">
              <div className="text-primary font-semibold font-inter">🎉 Course Complete! 🎉</div>
            </div>
          )}
        </nav>
      </main>
    </div>
  )
}

export default Page8FinalProject
