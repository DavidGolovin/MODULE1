"use client"

import { memo } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface CourseProgressBarProps {
  currentLesson: number
  totalLessons: number
  progressPercentage: number
  onPreviousLesson?: () => void
  onNextLesson?: () => void
  canGoBack?: boolean
  canGoForward?: boolean
  completedLessons?: Set<number>
}

const lessonTitles: Record<number, string> = {
  1: "Welcome",
  2: "HTML Basics",
  3: "HTML Structure",
  4: "HTML Forms",
  5: "HTML Tables",
  6: "Semantic HTML",
  7: "HTML Best Practices",
  8: "Final Project",
}

export const CourseProgressBar = memo<CourseProgressBarProps>(
  ({
    currentLesson,
    totalLessons,
    progressPercentage,
    onPreviousLesson,
    onNextLesson,
    canGoBack = true,
    canGoForward = true,
    completedLessons = new Set(),
  }) => {
    const currentLessonTitle = lessonTitles[currentLesson] || `Lesson ${currentLesson}`
    const isCurrentLessonCompleted = completedLessons.has(currentLesson)

    return (
      <div className="global-container sticky top-0 z-30">
        <div className="container mx-auto px-4 py-4">
          {/* Navigation and Title */}
          <div className="flex items-center justify-between mb-4">
            {/* Previous Button */}
            <button
              onClick={onPreviousLesson}
              disabled={!canGoBack}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-primary"
              aria-label="Go to previous lesson"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Previous</span>
            </button>

            {/* Current Lesson Info */}
            <div className="text-center">
              <div className="flex items-center gap-2 justify-center">
                <h2 className="text-lg font-bold text-primary font-inter">{currentLessonTitle}</h2>
                {isCurrentLessonCompleted && (
                  <div className="w-5 h-5 bg-primary text-white flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                )}
              </div>
              <p className="text-sm text-gray-600 font-inter">
                Lesson {currentLesson} of {totalLessons}
              </p>
            </div>

            {/* Next Button */}
            <button
              onClick={onNextLesson}
              disabled={!canGoForward}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-primary ${
                canGoForward ? "btn-primary" : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
              aria-label="Go to next lesson"
            >
              <span className="hidden sm:inline">Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Progress Bar */}
          <div className="relative mb-4">
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${progressPercentage}%` }}
                role="progressbar"
                aria-valuenow={progressPercentage}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`Course progress: ${progressPercentage}% complete`}
              />
            </div>

            {/* Progress Text */}
            <div className="flex justify-between items-center mt-2">
              <span className="text-xs text-gray-600 font-inter">{progressPercentage}% Complete</span>
              <span className="text-xs text-gray-600 font-inter">
                {completedLessons.size} / {totalLessons} lessons completed
              </span>
            </div>
          </div>

          {/* Lesson Indicators */}
          <div className="flex justify-center gap-2">
            {Array.from({ length: totalLessons }, (_, index) => {
              const lessonNumber = index + 1
              const isActive = lessonNumber === currentLesson
              const isCompleted = completedLessons.has(lessonNumber)

              return (
                <div
                  key={lessonNumber}
                  className={`w-3 h-3 transition-all duration-300 ${
                    isActive ? "bg-primary scale-125" : isCompleted ? "bg-primary opacity-60" : "bg-gray-300"
                  }`}
                  title={`${lessonTitles[lessonNumber] || `Lesson ${lessonNumber}`} ${
                    isCompleted ? "- Completed" : ""
                  }`}
                  role="button"
                  tabIndex={0}
                  aria-label={`${lessonTitles[lessonNumber] || `Lesson ${lessonNumber}`} ${
                    isActive ? "(current)" : isCompleted ? "(completed)" : ""
                  }`}
                />
              )
            })}
          </div>
        </div>
      </div>
    )
  },
)

CourseProgressBar.displayName = "CourseProgressBar"
