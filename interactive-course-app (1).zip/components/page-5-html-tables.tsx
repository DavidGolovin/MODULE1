"use client"

import { memo, useState, useCallback, useMemo } from "react"
import { PageContainer } from "./page-container"
import { EnhancedCard } from "./enhanced-card"
import { EnhancedButton } from "./enhanced-button"
import { InfoModal } from "./info-modal"
import { SuccessBurst } from "./success-burst"
import { FloatingElements } from "./floating-elements"
import { Table, Grid, BarChart3, CheckCircle, Code } from "lucide-react"

export const Page5_HtmlTables = memo(() => {
  const [showModal, setShowModal] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [selectedExample, setSelectedExample] = useState<string | null>(null)
  const [completedSections, setCompletedSections] = useState<Set<string>>(new Set())

  const tableElements = useMemo(
    () => [
      {
        id: "table",
        tag: "<table>",
        description: "Container for the entire table",
        usage: "Wraps all table content",
        example: "<table>\n  <!-- table content -->\n</table>",
      },
      {
        id: "thead",
        tag: "<thead>",
        description: "Groups header content",
        usage: "Contains table headers",
        example: "<thead>\n  <tr>\n    <th>Header 1</th>\n    <th>Header 2</th>\n  </tr>\n</thead>",
      },
      {
        id: "tbody",
        tag: "<tbody>",
        description: "Groups body content",
        usage: "Contains main table data",
        example: "<tbody>\n  <tr>\n    <td>Data 1</td>\n    <td>Data 2</td>\n  </tr>\n</tbody>",
      },
      {
        id: "tfoot",
        tag: "<tfoot>",
        description: "Groups footer content",
        usage: "Contains table footers/summaries",
        example: "<tfoot>\n  <tr>\n    <td>Total</td>\n    <td>$100</td>\n  </tr>\n</tfoot>",
      },
      {
        id: "tr",
        tag: "<tr>",
        description: "Table row",
        usage: "Creates horizontal rows",
        example: "<tr>\n  <td>Cell 1</td>\n  <td>Cell 2</td>\n</tr>",
      },
      {
        id: "th",
        tag: "<th>",
        description: "Table header cell",
        usage: "Column or row headers",
        example: '<th scope="col">Product Name</th>',
      },
      {
        id: "td",
        tag: "<td>",
        description: "Table data cell",
        usage: "Regular data cells",
        example: "<td>Apple iPhone</td>",
      },
      {
        id: "caption",
        tag: "<caption>",
        description: "Table title/description",
        usage: "Describes table purpose",
        example: "<caption>Monthly Sales Report</caption>",
      },
    ],
    [],
  )

  const sampleTables = useMemo(
    () => ({
      basic: `<table>
  <caption>Student Grades</caption>
  <thead>
    <tr>
      <th>Student Name</th>
      <th>Math</th>
      <th>Science</th>
      <th>English</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Alice Johnson</td>
      <td>95</td>
      <td>87</td>
      <td>92</td>
    </tr>
    <tr>
      <td>Bob Smith</td>
      <td>78</td>
      <td>91</td>
      <td>85</td>
    </tr>
    <tr>
      <td>Carol Davis</td>
      <td>88</td>
      <td>94</td>
      <td>89</td>
    </tr>
  </tbody>
</table>`,

      complex: `<table>
  <caption>Quarterly Sales Report</caption>
  <thead>
    <tr>
      <th rowspan="2">Product</th>
      <th colspan="4">Quarters</th>
      <th rowspan="2">Total</th>
    </tr>
    <tr>
      <th>Q1</th>
      <th>Q2</th>
      <th>Q3</th>
      <th>Q4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Laptops</th>
      <td>$50,000</td>
      <td>$65,000</td>
      <td>$70,000</td>
      <td>$80,000</td>
      <td>$265,000</td>
    </tr>
    <tr>
      <th scope="row">Phones</th>
      <td>$30,000</td>
      <td>$45,000</td>
      <td>$55,000</td>
      <td>$60,000</td>
      <td>$190,000</td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
      <th scope="row">Total</th>
      <td>$80,000</td>
      <td>$110,000</td>
      <td>$125,000</td>
      <td>$140,000</td>
      <td>$455,000</td>
    </tr>
  </tfoot>
</table>`,

      accessible: `<table>
  <caption>Employee Information</caption>
  <thead>
    <tr>
      <th scope="col" id="name">Name</th>
      <th scope="col" id="dept">Department</th>
      <th scope="col" id="salary">Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row" headers="name">John Doe</th>
      <td headers="dept">Engineering</td>
      <td headers="salary">$75,000</td>
    </tr>
    <tr>
      <th scope="row" headers="name">Jane Smith</th>
      <td headers="dept">Marketing</td>
      <td headers="salary">$65,000</td>
    </tr>
  </tbody>
</table>`,
    }),
    [],
  )

  const handleOpenModal = useCallback(() => {
    setShowModal(true)
  }, [])

  const handleCloseModal = useCallback(() => {
    setShowModal(false)
  }, [])

  const handleElementSelect = useCallback((elementId: string) => {
    setCompletedSections((prev) => new Set([...prev, elementId]))
    setShowSuccess(true)
  }, [])

  const handleExampleSelect = useCallback((exampleId: string) => {
    setSelectedExample(exampleId)
    setCompletedSections((prev) => new Set([...prev, `example-${exampleId}`]))
  }, [])

  const isCompleted = useCallback(
    (elementId: string) => {
      return completedSections.has(elementId)
    },
    [completedSections],
  )

  return (
    <PageContainer
      title="HTML Tables: Organizing Data"
      subtitle="Learn how to create structured, accessible data tables"
    >
      <FloatingElements />

      <div className="space-y-8">
        {/* Introduction */}
        <EnhancedCard className="animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-roots-primary-accent rounded-xl">
              <Table className="w-8 h-8 text-roots-text" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-roots-text mb-3 font-inter">When to Use Tables</h2>
              <p className="text-roots-dark-gray mb-4 font-inter leading-relaxed">
                HTML tables are designed for displaying tabular data - information that naturally fits into rows and
                columns. They should NOT be used for page layout, but are perfect for data like spreadsheets, schedules,
                price lists, and comparison charts.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
                  <h4 className="font-bold text-green-700 font-inter text-sm mb-2">✓ Good Uses</h4>
                  <ul className="text-xs text-green-600 font-inter space-y-1">
                    <li>• Financial reports and data</li>
                    <li>• Product comparison charts</li>
                    <li>• Schedules and timetables</li>
                    <li>• Statistical information</li>
                  </ul>
                </div>
                <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                  <h4 className="font-bold text-red-700 font-inter text-sm mb-2">✗ Avoid For</h4>
                  <ul className="text-xs text-red-600 font-inter space-y-1">
                    <li>• Page layout and positioning</li>
                    <li>• Creating columns for text</li>
                    <li>• Styling and visual design</li>
                    <li>• Non-tabular content</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </EnhancedCard>

        {/* Table Elements */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tableElements.map((element, index) => (
            <EnhancedCard
              key={element.id}
              className={`cursor-pointer transition-all duration-300 animate-fade-in-up ${
                isCompleted(element.id) ? "bg-green-50 border-green-200" : ""
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => handleElementSelect(element.id)}
            >
              <div className="flex items-center justify-between mb-3">
                <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded font-mono text-sm">
                  {element.tag}
                </code>
                {isCompleted(element.id) && <CheckCircle className="w-5 h-5 text-green-500" />}
              </div>
              <h4 className="font-bold text-roots-text mb-2 font-inter">{element.description}</h4>
              <p className="text-sm text-roots-dark-gray font-inter mb-3">{element.usage}</p>
              <code className="block bg-roots-container-bg p-2 rounded text-xs font-mono text-roots-text overflow-x-auto whitespace-pre-wrap">
                {element.example}
              </code>
            </EnhancedCard>
          ))}
        </div>

        {/* Table Examples */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
          <div className="flex items-center gap-3 mb-6">
            <Grid className="w-6 h-6 text-roots-icon-color" />
            <h3 className="text-xl font-bold text-roots-text font-inter">Table Examples</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <EnhancedButton
              variant={selectedExample === "basic" ? "primary" : "secondary"}
              onClick={() => handleExampleSelect("basic")}
              className="w-full"
            >
              Basic Table
            </EnhancedButton>
            <EnhancedButton
              variant={selectedExample === "complex" ? "primary" : "secondary"}
              onClick={() => handleExampleSelect("complex")}
              className="w-full"
            >
              Complex Table
            </EnhancedButton>
            <EnhancedButton
              variant={selectedExample === "accessible" ? "primary" : "secondary"}
              onClick={() => handleExampleSelect("accessible")}
              className="w-full"
            >
              Accessible Table
            </EnhancedButton>
          </div>

          {selectedExample && (
            <div className="space-y-4">
              <div className="bg-roots-container-bg p-4 rounded-lg">
                <h4 className="font-bold text-roots-text mb-3 font-inter">HTML Code:</h4>
                <pre className="text-xs font-mono text-roots-text overflow-x-auto whitespace-pre-wrap">
                  {sampleTables[selectedExample as keyof typeof sampleTables]}
                </pre>
              </div>

              <div className="bg-roots-page-bg border border-roots-border-line p-4 rounded-lg">
                <h4 className="font-bold text-roots-text mb-3 font-inter">Preview:</h4>
                <div
                  className="overflow-x-auto"
                  dangerouslySetInnerHTML={{
                    __html: sampleTables[selectedExample as keyof typeof sampleTables],
                  }}
                  style={{
                    fontSize: "12px",
                  }}
                />
              </div>

              <EnhancedButton
                variant="secondary"
                size="sm"
                onClick={() =>
                  navigator.clipboard.writeText(sampleTables[selectedExample as keyof typeof sampleTables])
                }
              >
                Copy Code
              </EnhancedButton>
            </div>
          )}
        </EnhancedCard>

        {/* Table Accessibility */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "1s" }}>
          <div className="flex items-center gap-3 mb-6">
            <BarChart3 className="w-6 h-6 text-roots-icon-color" />
            <h3 className="text-xl font-bold text-roots-text font-inter">Table Accessibility</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">Essential Attributes</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">scope</code>
                  <div>
                    <span className="text-roots-text font-inter font-medium">Defines header scope</span>
                    <p className="text-roots-dark-gray font-inter text-xs">
                      Use "col" for column headers, "row" for row headers
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">headers</code>
                  <div>
                    <span className="text-roots-text font-inter font-medium">Links cells to headers</span>
                    <p className="text-roots-dark-gray font-inter text-xs">References header IDs for complex tables</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <code className="bg-roots-primary-accent text-roots-text px-2 py-1 rounded text-xs">caption</code>
                  <div>
                    <span className="text-roots-text font-inter font-medium">Table description</span>
                    <p className="text-roots-dark-gray font-inter text-xs">Provides context for screen readers</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">Best Practices</h4>
              <ul className="space-y-2 text-sm text-roots-dark-gray font-inter">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Always include table headers (&lt;th&gt;)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Use &lt;caption&gt; to describe table purpose</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Group related content with thead, tbody, tfoot</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Use scope attribute for simple tables</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                  <span>Consider responsive design for mobile</span>
                </li>
              </ul>
            </div>
          </div>
        </EnhancedCard>

        {/* Advanced Features */}
        <EnhancedCard className="animate-fade-in-up" style={{ animationDelay: "1.2s" }}>
          <h3 className="text-xl font-bold text-roots-text mb-6 font-inter">Advanced Table Features</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">Spanning Cells</h4>
              <div className="bg-roots-light-gray p-3 rounded-lg mb-3">
                <code className="text-sm font-mono text-roots-text">
                  &lt;td colspan="2"&gt;Spans 2 columns&lt;/td&gt;
                  <br />
                  &lt;td rowspan="3"&gt;Spans 3 rows&lt;/td&gt;
                </code>
              </div>
              <p className="text-sm text-roots-dark-gray font-inter">
                Use colspan and rowspan to merge cells horizontally or vertically.
              </p>
            </div>

            <div>
              <h4 className="font-bold text-roots-text mb-3 font-inter">Styling with CSS</h4>
              <div className="bg-roots-light-gray p-3 rounded-lg mb-3">
                <code className="text-sm font-mono text-roots-text">
                  table &#123; border-collapse: collapse; &#125;
                  <br />
                  th, td &#123; border: 1px solid #ddd; &#125;
                  <br />
                  th &#123; background-color: #f2f2f2; &#125;
                </code>
              </div>
              <p className="text-sm text-roots-dark-gray font-inter">
                Use CSS to style tables - never use HTML attributes for styling.
              </p>
            </div>
          </div>
        </EnhancedCard>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <EnhancedButton size="lg" onClick={handleOpenModal}>
            <Code className="w-4 h-4 mr-2" />
            View More Examples
          </EnhancedButton>
          <EnhancedButton size="lg" variant="success">
            Practice Building Tables
          </EnhancedButton>
        </div>
      </div>

      {/* More Examples Modal */}
      <InfoModal isOpen={showModal} onClose={handleCloseModal} title="Additional Table Examples">
        <div className="space-y-6">
          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Price Comparison Table</h4>
            <code className="block bg-roots-container-bg p-3 rounded text-xs font-mono text-roots-text overflow-x-auto whitespace-pre-wrap">
              {`<table>
  <caption>Hosting Plan Comparison</caption>
  <thead>
    <tr>
      <th scope="col">Feature</th>
      <th scope="col">Basic</th>
      <th scope="col">Pro</th>
      <th scope="col">Enterprise</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Storage</th>
      <td>10GB</td>
      <td>100GB</td>
      <td>Unlimited</td>
    </tr>
    <tr>
      <th scope="row">Bandwidth</th>
      <td>100GB</td>
      <td>1TB</td>
      <td>Unlimited</td>
    </tr>
    <tr>
      <th scope="row">Price</th>
      <td>$5/month</td>
      <td>$15/month</td>
      <td>$50/month</td>
    </tr>
  </tbody>
</table>`}
            </code>
          </div>

          <div>
            <h4 className="font-bold text-roots-text mb-3 font-inter">Schedule Table</h4>
            <code className="block bg-roots-container-bg p-3 rounded text-xs font-mono text-roots-text overflow-x-auto whitespace-pre-wrap">
              {`<table>
  <caption>Weekly Class Schedule</caption>
  <thead>
    <tr>
      <th scope="col">Time</th>
      <th scope="col">Monday</th>
      <th scope="col">Tuesday</th>
      <th scope="col">Wednesday</th>
      <th scope="col">Thursday</th>
      <th scope="col">Friday</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">9:00 AM</th>
      <td>Math</td>
      <td>Science</td>
      <td>Math</td>
      <td>Science</td>
      <td>Art</td>
    </tr>
    <tr>
      <th scope="row">10:00 AM</th>
      <td>English</td>
      <td>Math</td>
      <td>English</td>
      <td>Math</td>
      <td>Music</td>
    </tr>
  </tbody>
</table>`}
            </code>
          </div>
        </div>
      </InfoModal>

      <SuccessBurst
        show={showSuccess}
        message="Great job! You're mastering HTML tables!"
        onComplete={() => setShowSuccess(false)}
      />
    </PageContainer>
  )
})

Page5_HtmlTables.displayName = "Page5_HtmlTables"
