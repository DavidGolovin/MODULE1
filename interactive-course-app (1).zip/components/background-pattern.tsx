"use client"

import { memo } from "react"

interface BackgroundPatternProps {
  pattern?: "dots" | "grid" | "diagonal" | "waves" | "hexagon" | "circuit"
  className?: string
}

export const BackgroundPattern = memo<BackgroundPatternProps>(({ pattern = "dots", className = "" }) => {
  const getPatternClass = () => {
    switch (pattern) {
      case "dots":
        return "bg-pattern-dots"
      case "grid":
        return "bg-pattern-grid"
      case "diagonal":
        return "bg-pattern-diagonal"
      case "waves":
        return "bg-pattern-waves"
      case "hexagon":
        return "bg-pattern-hexagon"
      case "circuit":
        return "bg-pattern-circuit"
      default:
        return "bg-pattern-dots"
    }
  }

  return (
    <div className={`fixed inset-0 pointer-events-none z-0 ${getPatternClass()} ${className}`} aria-hidden="true" />
  )
})

BackgroundPattern.displayName = "BackgroundPattern"
