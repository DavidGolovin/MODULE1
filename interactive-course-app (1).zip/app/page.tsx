"use client"

import { useState, useCallback, useMemo } from "react"
import { Page1_Welcome } from "@/components/page-1-welcome"
import { Page2_Introduction } from "@/components/page-2-introduction"
import { Page3_MarketTrends } from "@/components/page-3-market-trends"
import { Page4_Calculator } from "@/components/page-4-calculator"
import { Page5_WinWin } from "@/components/page-5-win-win"
import { Page6_EligibleLoans } from "@/components/page-6-eligible-loans"
import { Page7_Quiz } from "@/components/page-7-quiz"
import { Page8FinalProject } from "@/components/page-8-final-project"
import { CourseProgressBar } from "@/components/course-progress-bar"
import { LessonGrid } from "@/components/lesson-grid"
import { useCourseProgress } from "@/hooks/use-course-progress"

export default function HTMLFundamentalsCourse() {
  const {
    currentLesson,
    completedLessons,
    progressPercentage,
    isLoaded,
    navigateToLesson,
    markLessonCompleted,
    nextLesson,
    previousLesson,
    canGoNext,
    canGoPrevious,
    isLessonCompleted,
  } = useCourseProgress(8)

  const [userName, setUserName] = useState("")
  const [isUserNameConfirmed, setIsUserNameConfirmed] = useState(false)

  // Enhanced completion handler
  const handleLessonCompletion = useCallback(
    (lessonNumber: number, completed: boolean) => {
      if (completed) {
        markLessonCompleted(lessonNumber)
      }
    },
    [markLessonCompleted],
  )

  const handleUserNameConfirmed = useCallback(
    (confirmed: boolean, name: string) => {
      setIsUserNameConfirmed(confirmed)
      setUserName(name)
      if (confirmed) {
        handleLessonCompletion(1, true)
      }
    },
    [handleLessonCompletion],
  )

  const handleAdvanceToNextPage = useCallback(() => {
    if (canGoNext) {
      nextLesson()
    }
  }, [canGoNext, nextLesson])

  const handleGoToPreviousPage = useCallback(() => {
    if (canGoPrevious) {
      previousLesson()
    }
  }, [canGoPrevious, previousLesson])

  const currentPageComponent = useMemo(() => {
    if (!isLoaded) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-primary font-inter">Loading your progress...</div>
        </div>
      )
    }

    switch (currentLesson) {
      case 1:
        return (
          <Page1_Welcome
            onUserNameConfirmed={handleUserNameConfirmed}
            onAdvanceToNextPage={handleAdvanceToNextPage}
            userName={userName}
            isCompleted={isLessonCompleted(1)}
          />
        )
      case 2:
        return (
          <Page2_Introduction
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(2, completed)}
            isCompleted={isLessonCompleted(2)}
          />
        )
      case 3:
        return (
          <Page3_MarketTrends
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(3, completed)}
            isCompleted={isLessonCompleted(3)}
          />
        )
      case 4:
        return (
          <Page4_Calculator
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(4, completed)}
            isCompleted={isLessonCompleted(4)}
          />
        )
      case 5:
        return (
          <Page5_WinWin
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(5, completed)}
            isCompleted={isLessonCompleted(5)}
          />
        )
      case 6:
        return (
          <Page6_EligibleLoans
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(6, completed)}
            isCompleted={isLessonCompleted(6)}
          />
        )
      case 7:
        return (
          <Page7_Quiz
            onAllTrueFalseAnswered={() => {
              handleLessonCompletion(7, true)
            }}
            onNextPage={handleAdvanceToNextPage}
            onPrevPage={handleGoToPreviousPage}
            isCompleted={isLessonCompleted(7)}
          />
        )
      case 8:
        return (
          <Page8FinalProject
            onPrevPage={handleGoToPreviousPage}
            onPageCompletion={(completed) => handleLessonCompletion(8, completed)}
            isCompleted={isLessonCompleted(8)}
          />
        )
      default:
        return (
          <Page1_Welcome
            onUserNameConfirmed={handleUserNameConfirmed}
            onAdvanceToNextPage={handleAdvanceToNextPage}
            userName={userName}
            isCompleted={isLessonCompleted(1)}
          />
        )
    }
  }, [
    currentLesson,
    isLoaded,
    userName,
    isLessonCompleted,
    handleUserNameConfirmed,
    handleAdvanceToNextPage,
    handleGoToPreviousPage,
    handleLessonCompletion,
  ])

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-primary font-inter text-lg">Loading your course progress...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Course Header */}
      <header className="global-container" role="banner">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold text-primary font-inter">HTML Fundamentals Course</h1>
            <p className="text-xl text-gray-600 font-inter max-w-3xl mx-auto">
              Master the building blocks of the web with hands-on lessons and interactive exercises
            </p>

            {/* Lesson Grid - Only show on lesson 1 */}
            {currentLesson === 1 && (
              <div className="pt-8">
                <LessonGrid
                  currentLesson={currentLesson}
                  completedLessons={completedLessons}
                  onLessonSelect={navigateToLesson}
                />
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Progress Bar - Show for lessons 2-8 */}
      {currentLesson > 1 && (
        <CourseProgressBar
          currentLesson={currentLesson}
          totalLessons={8}
          progressPercentage={progressPercentage}
          onPreviousLesson={handleGoToPreviousPage}
          onNextLesson={handleAdvanceToNextPage}
          canGoBack={canGoPrevious}
          canGoForward={canGoNext}
          completedLessons={completedLessons}
        />
      )}

      {/* Main Content */}
      <main role="main">{currentPageComponent}</main>
    </div>
  )
}
