"use client"

import { useState, useEffect, useCallback } from "react"

const STORAGE_KEY = "course-progress"
const CURRENT_LESSON_KEY = "current-lesson"

interface CourseProgress {
  currentLesson: number
  completedLessons: Set<number>
  lastAccessed: string
}

export function useCourseProgress(totalLessons = 8) {
  const [currentLesson, setCurrentLesson] = useState(1)
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set())
  const [isLoaded, setIsLoaded] = useState(false)

  // Calculate progress percentage with fixed logic
  const calculateProgress = useCallback(
    (lesson: number, completed: Set<number>) => {
      if (lesson === 1) return 1 // Lesson 1 = 1%

      // Remaining 99% distributed across 7 lessons (lessons 2-8)
      // Each lesson gets ~14.14%, rounded to ensure total = 100%
      const remainingLessons = totalLessons - 1
      const basePercentage = Math.floor(99 / remainingLessons)
      const remainder = 99 % remainingLessons

      let progress = 1 // Start with 1% for lesson 1

      for (let i = 2; i <= lesson; i++) {
        // Add extra 1% to first 'remainder' lessons to distribute the remainder
        const lessonProgress = basePercentage + (i - 2 < remainder ? 1 : 0)
        progress += lessonProgress
      }

      return Math.min(progress, 100)
    },
    [totalLessons],
  )

  const progressPercentage = calculateProgress(currentLesson, completedLessons)

  // Load progress from localStorage
  useEffect(() => {
    try {
      const savedProgress = localStorage.getItem(STORAGE_KEY)
      const savedCurrentLesson = localStorage.getItem(CURRENT_LESSON_KEY)

      if (savedProgress) {
        const parsed: CourseProgress = JSON.parse(savedProgress)
        setCompletedLessons(new Set(parsed.completedLessons || []))
      }

      if (savedCurrentLesson) {
        const lessonNum = Number.parseInt(savedCurrentLesson, 10)
        if (lessonNum >= 1 && lessonNum <= totalLessons) {
          setCurrentLesson(lessonNum)
        }
      }
    } catch (error) {
      console.warn("Failed to load course progress:", error)
    } finally {
      setIsLoaded(true)
    }
  }, [totalLessons])

  // Save progress to localStorage
  const saveProgress = useCallback((lesson: number, completed: Set<number>) => {
    try {
      const progress: CourseProgress = {
        currentLesson: lesson,
        completedLessons: Array.from(completed),
        lastAccessed: new Date().toISOString(),
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress))
      localStorage.setItem(CURRENT_LESSON_KEY, lesson.toString())
    } catch (error) {
      console.warn("Failed to save course progress:", error)
    }
  }, [])

  // Navigate to specific lesson
  const navigateToLesson = useCallback(
    (lessonNumber: number) => {
      if (lessonNumber >= 1 && lessonNumber <= totalLessons) {
        setCurrentLesson(lessonNumber)
        saveProgress(lessonNumber, completedLessons)
      }
    },
    [totalLessons, completedLessons, saveProgress],
  )

  // Mark lesson as completed
  const markLessonCompleted = useCallback(
    (lessonNumber: number) => {
      setCompletedLessons((prev) => {
        const newCompleted = new Set(prev)
        newCompleted.add(lessonNumber)
        saveProgress(currentLesson, newCompleted)
        return newCompleted
      })
    },
    [currentLesson, saveProgress],
  )

  // Navigation helpers
  const nextLesson = useCallback(() => {
    if (currentLesson < totalLessons) {
      const nextLessonNum = currentLesson + 1
      setCurrentLesson(nextLessonNum)
      saveProgress(nextLessonNum, completedLessons)
    }
  }, [currentLesson, totalLessons, completedLessons, saveProgress])

  const previousLesson = useCallback(() => {
    if (currentLesson > 1) {
      const prevLessonNum = currentLesson - 1
      setCurrentLesson(prevLessonNum)
      saveProgress(prevLessonNum, completedLessons)
    }
  }, [currentLesson, completedLessons, saveProgress])

  // Check if can navigate
  const canGoNext = currentLesson < totalLessons
  const canGoPrevious = currentLesson > 1

  // Check if lesson is completed
  const isLessonCompleted = useCallback(
    (lessonNumber: number) => {
      return completedLessons.has(lessonNumber)
    },
    [completedLessons],
  )

  return {
    currentLesson,
    completedLessons,
    progressPercentage,
    isLoaded,
    navigateToLesson,
    markLessonCompleted,
    nextLesson,
    previousLesson,
    canGoNext,
    canGoPrevious,
    isLessonCompleted,
  }
}
