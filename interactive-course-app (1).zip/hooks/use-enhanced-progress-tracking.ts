"use client"

import { useState, useEffect, useCallback } from "react"

const STORAGE_KEY = "course_progress_v2"
const CURRENT_LESSON_KEY = "current_lesson_v2"

interface ProgressData {
  currentLesson: number
  completedLessons: Set<number>
  lastAccessed: number
  progressPercentage: number
}

export function useEnhancedProgressTracking(totalLessons = 15) {
  const [currentLesson, setCurrentLesson] = useState(1)
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set())
  const [isLoaded, setIsLoaded] = useState(false)
  const [progressPercentage, setProgressPercentage] = useState(1)

  // Calculate progress percentage with corrected logic
  const calculateProgress = useCallback((lesson: number, completed: Set<number>): number => {
    if (lesson === 1) return 1 // First lesson is 1%

    // Remaining 99% distributed across 7 lessons (lessons 2-8)
    // Each lesson after the first adds ~14% (99/7 = 14.14, rounded)
    const progressSteps = [1, 15, 29, 43, 57, 71, 85, 100] // 8 lessons total

    // Find the highest completed lesson or current lesson
    const maxLesson = Math.max(lesson, Math.max(...Array.from(completed), 0))
    const lessonIndex = Math.min(maxLesson - 1, progressSteps.length - 1)

    return progressSteps[lessonIndex] || 1
  }, [])

  // Load progress from localStorage
  useEffect(() => {
    if (typeof window === "undefined") return

    try {
      const savedProgress = localStorage.getItem(STORAGE_KEY)
      const savedLesson = localStorage.getItem(CURRENT_LESSON_KEY)

      if (savedProgress) {
        const data = JSON.parse(savedProgress)
        const completedSet = new Set(data.completedLessons || [])
        setCompletedLessons(completedSet)

        if (data.currentLesson) {
          const lessonNum = Number(data.currentLesson)
          if (lessonNum >= 1 && lessonNum <= totalLessons) {
            setCurrentLesson(lessonNum)
            setProgressPercentage(calculateProgress(lessonNum, completedSet))
          }
        }
      }

      if (savedLesson) {
        const lessonNum = Number.parseInt(savedLesson, 10)
        if (lessonNum >= 1 && lessonNum <= totalLessons) {
          setCurrentLesson(lessonNum)
          setProgressPercentage(calculateProgress(lessonNum, completedLessons))
        }
      }
    } catch (error) {
      console.warn("Failed to load progress from localStorage:", error)
    } finally {
      setIsLoaded(true)
    }
  }, [totalLessons, calculateProgress, completedLessons])

  // Save progress to localStorage
  const saveProgress = useCallback(
    (lesson: number, completed: Set<number>) => {
      if (typeof window === "undefined") return

      try {
        const progressData: ProgressData = {
          currentLesson: lesson,
          completedLessons: completed,
          lastAccessed: Date.now(),
          progressPercentage: calculateProgress(lesson, completed),
        }

        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({
            ...progressData,
            completedLessons: Array.from(completed),
          }),
        )
        localStorage.setItem(CURRENT_LESSON_KEY, lesson.toString())
      } catch (error) {
        console.warn("Failed to save progress to localStorage:", error)
      }
    },
    [calculateProgress],
  )

  // Navigate to lesson
  const navigateToLesson = useCallback(
    (lesson: number) => {
      if (lesson >= 1 && lesson <= totalLessons) {
        setCurrentLesson(lesson)
        const newProgress = calculateProgress(lesson, completedLessons)
        setProgressPercentage(newProgress)
        saveProgress(lesson, completedLessons)
      }
    },
    [completedLessons, saveProgress, totalLessons, calculateProgress],
  )

  // Mark lesson as completed
  const markLessonCompleted = useCallback(
    (lesson: number) => {
      const newCompleted = new Set(completedLessons)
      newCompleted.add(lesson)
      setCompletedLessons(newCompleted)
      const newProgress = calculateProgress(currentLesson, newCompleted)
      setProgressPercentage(newProgress)
      saveProgress(currentLesson, newCompleted)
    },
    [completedLessons, currentLesson, saveProgress, calculateProgress],
  )

  // Go to next lesson
  const nextLesson = useCallback(() => {
    if (currentLesson < totalLessons) {
      const nextLessonNum = currentLesson + 1
      navigateToLesson(nextLessonNum)
    }
  }, [currentLesson, totalLessons, navigateToLesson])

  // Go to previous lesson
  const previousLesson = useCallback(() => {
    if (currentLesson > 1) {
      const prevLessonNum = currentLesson - 1
      navigateToLesson(prevLessonNum)
    }
  }, [currentLesson, navigateToLesson])

  // Reset progress
  const resetProgress = useCallback(() => {
    setCurrentLesson(1)
    setCompletedLessons(new Set())
    setProgressPercentage(1)
    if (typeof window !== "undefined") {
      localStorage.removeItem(STORAGE_KEY)
      localStorage.removeItem(CURRENT_LESSON_KEY)
    }
  }, [])

  return {
    currentLesson,
    completedLessons,
    progressPercentage,
    isLoaded,
    navigateToLesson,
    markLessonCompleted,
    nextLesson,
    previousLesson,
    resetProgress,
    canGoNext: currentLesson < totalLessons,
    canGoPrevious: currentLesson > 1,
    isLessonCompleted: (lesson: number) => completedLessons.has(lesson),
  }
}
